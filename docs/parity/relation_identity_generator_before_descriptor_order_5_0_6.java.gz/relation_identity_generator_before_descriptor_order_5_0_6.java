package com.skynet.codegenerator.cpp;

import cn.hutool.core.io.resource.ResourceUtil;
import cn.hutool.core.text.NamingCase;
import com.skynet.codegenerator.AbstractGenerator;
import com.skynet.codegenerator.DomainGenerationService;
import com.skynet.codegenerator.GenerateContext;
import com.skynet.codegenerator.GeneratedFile;
import com.skynet.codegenerator.meta.*;
import com.skynet.codegenerator.naming.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.regex.Pattern;

/** C++20 entity/query/evaluation frontend over the existing parsed KSML model. */
public class CppCoreGenerator extends AbstractGenerator {
  public static final String SCOPE = "cpp-lib-core";

  public CppCoreGenerator() { this(false); }

  public CppCoreGenerator(boolean inheritanceQualification) {
    this(inheritanceQualification, false);
  }

  public CppCoreGenerator(boolean inheritanceQualification, boolean constantQualification) {
    // Preserve existing development callers; both surfaces use normal generation.
  }
  private static final Set<String> KEYWORDS =
      Set.of(
          "alignas",
          "alignof",
          "and",
          "asm",
          "auto",
          "bool",
          "break",
          "case",
          "catch",
          "char",
          "class",
          "concept",
          "const",
          "consteval",
          "constexpr",
          "constinit",
          "continue",
          "co_await",
          "co_return",
          "co_yield",
          "decltype",
          "default",
          "delete",
          "do",
          "double",
          "else",
          "enum",
          "explicit",
          "export",
          "extern",
          "false",
          "float",
          "for",
          "friend",
          "goto",
          "if",
          "import",
          "inline",
          "int",
          "long",
          "module",
          "mutable",
          "namespace",
          "new",
          "noexcept",
          "not",
          "nullptr",
          "operator",
          "or",
          "private",
          "protected",
          "public",
          "register",
          "requires",
          "return",
          "short",
          "signed",
          "sizeof",
          "static",
          "struct",
          "switch",
          "template",
          "this",
          "thread_local",
          "throw",
          "true",
          "try",
          "typedef",
          "typeid",
          "typename",
          "union",
          "unsigned",
          "using",
          "virtual",
          "void",
          "volatile",
          "wchar_t",
          "while",
          "xor");

  @Override
  public List<String> getScopes() {
    return List.of(SCOPE);
  }

  private static String identifier(String source) {
    String name = NamingCase.toUnderlineCase(source).replaceAll("[^A-Za-z0-9_]", "_");
    if (name.isEmpty() || Character.isDigit(name.charAt(0))) {
      name = "model_" + name;
    }
    if (KEYWORDS.contains(name) || name.startsWith("_") || name.contains("__")) {
      name = "model_" + name.replaceAll("_+", "_").replaceAll("^_", "");
    }
    return name;
  }

  private static String typeName(ObjectDescriptor od) {
    return RustObjectDescriptorNaming.rustStructName(od);
  }

  private static String fieldName(FieldDescriptor fd) {
    return identifier(RustFieldDescriptorNaming.rustStorageFieldName(fd));
  }

  private static String columnName(FieldDescriptor fd) {
    String configured = fd.getAttributeValue(Attributes.SQL_COLUMN);
    // EntityDescriptor stores raw identifiers; the runtime dialect quotes them.
    return configured == null ? FieldDescriptorNaming.canonicalPropertyName(fd) : configured;
  }

  private static String canonical(FieldDescriptor fd) {
    return RustFieldDescriptorNaming.rustStorageFieldName(fd);
  }

  private static String relationName(FieldDescriptor fd) {
    return identifier(fd.getName());
  }

  private static String relationName(ReverseRelation rel) {
    return identifier(RustReverseRelationNaming.rustMemberName(rel));
  }

  // Model identities are data. C++ keyword escaping applies only to emitted identifiers.
  private static String relationIdentity(FieldDescriptor fd) {
    return RustFieldDescriptorNaming.rustMemberName(fd);
  }

  private static String relationIdentity(ReverseRelation rel) {
    return RustReverseRelationNaming.rustMemberName(rel);
  }

  private static String quote(String text) {
    return "\""
        + text.replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", "\\n")
            .replace("\r", "\\r")
            .replace("\t", "\\t")
        + "\"";
  }

  private static List<FieldDescriptor> fields(ObjectDescriptor od) {
    return CppFieldLayoutMetadata.fields(od);
  }

  // Rust's derive describes scalar storage first, then generated foreign keys.
  // Indexed field-layout ordering remains the separate canonical model order.
  private static List<FieldDescriptor> descriptorFields(ObjectDescriptor od) {
    return java.util.stream.Stream.concat(
        fields(od).stream().filter(field -> !field.isObjectProperty()),
        fields(od).stream().filter(FieldDescriptor::isObjectProperty)).toList();
  }

  private static String baseType(FieldDescriptor fd) {
    if (fd.isObjectProperty()) {
      return "std::uint64_t";
    }
    String name = fd.getFieldType().getName();
    return switch (name) {
      case "id" -> "std::uint64_t";
      case "version", "integer", "long" -> "std::int64_t";
      case "float" -> "float";
      case "double" -> "double";
      case "number" -> "Decimal";
      case "bool" -> "bool";
      case "jsonMe" -> "Json";
      case "date" -> "Date";
      case "createTime", "updateTime", "dateTime" -> "Timestamp";
      default -> "String";
    };
  }

  private static String storageType(FieldDescriptor fd) {
    String base = baseType(fd);
    return fd.getBooleanAttribute("optional") ? "std::optional<" + base + ">" : base;
  }

  private static void validateConfiguredScalarStorage(FieldDescriptor field) {
    if (field.isObjectProperty() || CppBusinessIdMetadata.isBusinessId(field)
        || field.getFieldType().getAttributeValue("rustType") == null) {
      return;
    }
    // Read the type declaration, not a similarly named field parameter. The
    // frozen Rust naming layer deliberately ignores field-level rustType.
    String sourceType = RustTypeNaming.rustType(field.getFieldType());
    String nativeType = switch (sourceType) {
      case "String", "std::string::String", "alloc::string::String" -> "String";
      case "u64", "std::primitive::u64", "core::primitive::u64" -> "std::uint64_t";
      case "i64", "std::primitive::i64", "core::primitive::i64" -> "std::int64_t";
      case "f32" -> "float";
      case "f64" -> "double";
      case "bool" -> "bool";
      case "rust_decimal::Decimal" -> "Decimal";
      case "serde_json::Value" -> "Json";
      case "chrono::NaiveDate" -> "Date";
      case "teaql_core::time::Timestamp" -> "Timestamp";
      default -> null;
    };
    if (nativeType == null) {
      throw new IllegalArgumentException("C++ unsupported configured scalar type: "
          + field.getObjectDescriptor().getName() + "." + field.getName()
          + " (Rust " + sourceType + ")");
    }
    if (nativeType != null && !nativeType.equals(baseType(field))) {
      throw new IllegalArgumentException("C++ configured scalar storage mismatch: "
          + field.getObjectDescriptor().getName() + "." + field.getName()
          + " (Rust " + sourceType + ", C++ " + baseType(field) + ")");
    }
  }

  private static String applicationType(FieldDescriptor fd) {
    return CppBusinessIdMetadata.isBusinessId(fd)
        ? CppBusinessIdMetadata.typeName(fd)
        : storageType(fd);
  }

  private static String argumentType(FieldDescriptor fd) {
    if (CppBusinessIdMetadata.isBusinessId(fd)) {
      return "const " + applicationType(fd) + "&";
    }
    if (!fd.getBooleanAttribute("optional") && baseType(fd).equals("String")) {
      return "std::string_view";
    }
    return "const " + storageType(fd) + "&";
  }

  private static String predicateType(FieldDescriptor fd) {
    if (CppBusinessIdMetadata.isBusinessId(fd)) {
      return "const " + applicationType(fd) + "&";
    }
    return baseType(fd).equals("String") ? "std::string_view" : "const " + baseType(fd) + "&";
  }

  private static String dataType(FieldDescriptor fd) {
    return switch (baseType(fd)) {
      case "std::uint64_t" -> "U64";
      case "std::int64_t" -> "I64";
      case "float", "double" -> "F64";
      case "Decimal" -> "Decimal";
      case "bool" -> "Bool";
      case "Json" -> "Json";
      case "Date" -> "Date";
      case "Timestamp" -> "Timestamp";
      default -> fd.getBooleanAttribute("isText")
              || "LARGE_TEXT".equalsIgnoreCase(fd.getAttributeValue(Attributes.SQL_TYPE))
          ? "LargeText"
          : "Text";
    };
  }

  private static void line(StringBuilder out, String text) {
    out.append(text).append('\n');
  }

  private static String header(String ns, String include) {
    return "#pragma once\n// Generated by teaql-code-gen. Regenerate; do not edit.\n#include \""
        + include
        + "\"\n\nnamespace "
        + ns
        + " {\n";
  }

  @Override
  public List<GeneratedFile> generate(Domain raw) {
    Domain domain = new EntityDomain(raw);
    String ns = identifier(raw.getName());
    List<ObjectDescriptor> entities = domain.getObjectDescriptors();
    Set<String> names = new HashSet<>();
    Set<FieldDescriptor> businessFields = java.util.Collections.newSetFromMap(new java.util.IdentityHashMap<>());
    for (ObjectDescriptor od : entities) {
      if (!names.add(typeName(od))) {
        throw new IllegalArgumentException("C++ entity naming collision: " + od.getName());
      }
      Set<String> members = new HashSet<>();
      for (FieldDescriptor fd : fields(od)) {
        validateConfiguredScalarStorage(fd);
        if (CppBusinessIdMetadata.isBusinessId(fd)) {
          CppBusinessIdMetadata.validate(fd);
          if (businessFields.add(fd) && !names.add(CppBusinessIdMetadata.typeName(fd))) {
            throw new IllegalArgumentException(
                "C++ Business ID type naming collision: " + fd.getName());
          }
        }
        if (!members.add(fieldName(fd))) {
          throw new IllegalArgumentException(
              "C++ field naming collision: " + od.getName() + "." + fd.getName());
        }
        if (fd.isObjectProperty() && !members.add(relationName(fd))) {
          throw new IllegalArgumentException("C++ relation naming collision: " + fd.getName());
        }
      }
      for (ReverseRelation rel : od.getReverseRelations()) {
        if (!members.add(relationName(rel))) {
          throw new IllegalArgumentException(
              "C++ reverse relation naming collision: " + relationName(rel));
        }
      }
      if (od.isConstant()) {
        List<Candidate> identities = od.getIdentityConstants();
        if (identities != null) {
          for (Candidate identity : identities) {
            // Negative identities produce invalid names/u64 expressions in the
            // original Rust crate. Reject before emitting malformed C++ recipes.
            if (identity.getId() < 0) {
              throw new IllegalArgumentException("C++ constant identity is negative: "
                  + od.getName() + "(" + identity.getId() + ")");
            }
          }
        }
      }
      for (FieldDescriptor field : fields(od)) {
        Set<String> candidateMethods = new HashSet<>(List.of("isUnknown", "isKnown"));
        for (Candidate candidate : candidates(field)) {
          String suffix = candidate.getRustCandidateMethodValue();
          if (!candidateMethods.add(camel("is_" + suffix))
              || !candidateMethods.add(camel("is_not_" + suffix))) {
            throw new IllegalArgumentException("C++ candidate naming collision: "
                + od.getName() + "." + field.getName());
          }
        }
      }
      if (od.getDataService() != null
          && !"sqlite".equalsIgnoreCase(od.getDataService().getName())) {
        throw new IllegalArgumentException(
            "C++ edge generation supports SQLite only: " + od.getName());
      }
    }
    String prefix = "include/" + ns + "/";
    List<GeneratedFile> files = new ArrayList<>();
    files.add(
        createGeneratedFile(
            prefix + "support.hpp",
            ResourceUtil.readUtf8Str("generator/cpp_lib_core/support.hpp.template")
                .replace("@NAMESPACE@", ns)));
    files.add(createGeneratedFile(prefix + "models.hpp", models(ns, entities)));
    files.add(createGeneratedFile(prefix + "queries.hpp", queries(ns, entities)));
    files.add(createGeneratedFile(prefix + "expressions.hpp", expressions(ns, entities)));
    files.add(createGeneratedFile(prefix + "checkers.hpp", checkers(ns, entities)));
    files.add(createGeneratedFile(prefix + "runtime.hpp", runtime(ns, entities, domain)));
    files.add(createGeneratedFile(prefix + "sample_data.hpp", sampleData(ns, entities)));
    files.add(
        createGeneratedFile(
            "include/" + ns + ".hpp",
            "#pragma once\n#include \""
                + ns
                + "/queries.hpp\"\n#include \""
                + ns
                + "/expressions.hpp\"\n#include \""
                + ns
                + "/runtime.hpp\"\n#include \"" + ns + "/sample_data.hpp\"\n"));
    files.add(
        createGeneratedFile(
            "CMakeLists.txt",
            "cmake_minimum_required(VERSION 4.4)\nproject("
                + ns
                + " LANGUAGES CXX)\nfind_package(teaql_cpp CONFIG REQUIRED)\nadd_library("
                + ns
                + " INTERFACE)\ntarget_include_directories("
                + ns
                + " INTERFACE ${CMAKE_CURRENT_SOURCE_DIR}/include)\ntarget_compile_features("
                + ns
                + " INTERFACE cxx_std_20)\ntarget_link_libraries("
                + ns
                + " INTERFACE teaql::provider_sqlite)\n"));
    files.add(createGeneratedFile("ASSIST.md", assist(ns, entities)));
    files.add(
        createGeneratedFile(
            "AGENTS.md",
            "# Generated C++ application rules\n\n"
                + "Use ASSIST.md for current model-aware API discovery. Do not edit generated"
                + " headers.\n"
                + "Create auto Q = user_context.queries<query_factory>(); entries take no context"
                + " argument.\n"
                + "Application Q/E/model methods use lowerCamelCase; runtime protocols keep"
                + " snake_case.\n"
                + "Allocate through UserContext; call setup(UserContext&) before execution.\n"
                + "Name UserContext variables and parameters user_context; use descriptive variants"
                + " for multiple contexts. Do not abbreviate them to user.\n"
                + "Queries require nonblank purpose and comment. Saving requires"
                + " audit_as(reason).\n"
                + "Execution receives only UserContext. Results and expression borrows expire with"
                + " it.\n"));
    return files;
  }

  private String camelModelMethods(String source, List<ObjectDescriptor> entities) {
    java.util.Map<String, String> names = new java.util.HashMap<>();
    Set<String> modelTypes = entities.stream()
        .map(CppCoreGenerator::typeName).collect(java.util.stream.Collectors.toSet());
    for (ObjectDescriptor od : entities) {
      for (FieldDescriptor fd : fields(od)) {
        names.put(fieldName(fd), camel(fieldName(fd)));
        names.put("update_" + fieldName(fd), camel("update_" + fieldName(fd)));
      }
      for (FieldDescriptor fd :
          fields(od).stream().filter(FieldDescriptor::isObjectProperty).toList()) {
        names.put(relationName(fd), camel(relationName(fd)));
        names.put("update_" + relationName(fd), camel("update_" + relationName(fd)));
      }
      for (ReverseRelation rel : od.getReverseRelations()) {
        names.put(relationName(rel), camel(relationName(rel)));
      }
    }
    // Quoted canonical names remain untouched. Only callable domain identifiers change.
    java.util.regex.Matcher tokens =
        java.util.regex.Pattern.compile(
                "\"(?:\\\\.|[^\"\\\\])*\"|[A-Za-z_][A-Za-z_0-9]*(?=\\s*\\()")
            .matcher(source);
    StringBuffer result = new StringBuffer();
    while (tokens.find()) {
      boolean external = hasExternalQualifier(source, tokens.start(), modelTypes);
      tokens.appendReplacement(
          result,
          java.util.regex.Matcher.quoteReplacement(
              external ? tokens.group() : names.getOrDefault(tokens.group(), tokens.group())));
    }
    tokens.appendTail(result);
    return result.toString();
  }

  private static List<Candidate> candidates(FieldDescriptor field) {
    if (!field.isObjectProperty()) {
      return RustFieldDescriptorNaming.rustCandidates(field);
    }
    List<Candidate> values = field.getCandidateForConst();
    return values == null ? List.of() : values;
  }

  private static String candidateLiteral(FieldDescriptor field, Candidate candidate) {
    return field.isObjectProperty()
        ? "std::uint64_t{" + candidate.getId() + "}"
        : quote(candidate.getRustCandidateFilterValue());
  }

  private static boolean hasExternalQualifier(String source, int start, Set<String> modelTypes) {
    int scopeEnd = start;
    while (scopeEnd > 0 && Character.isWhitespace(source.charAt(scopeEnd - 1))) {
      --scopeEnd;
    }
    if (scopeEnd < 2 || !source.regionMatches(scopeEnd - 2, "::", 0, 2)) {
      return false;
    }
    int ownerEnd = scopeEnd - 2;
    while (ownerEnd > 0 && Character.isWhitespace(source.charAt(ownerEnd - 1))) {
      --ownerEnd;
    }
    int ownerStart = ownerEnd;
    while (ownerStart > 0 && Character.isJavaIdentifierPart(source.charAt(ownerStart - 1))) {
      --ownerStart;
    }
    return !modelTypes.contains(source.substring(ownerStart, ownerEnd));
  }

  private static boolean hasGeneratedBootstrap(List<ObjectDescriptor> entities) {
    return entities.stream().filter(entity -> entity.isRoot() && !entity.isConstant()).count() == 1;
  }

  private String models(String ns, List<ObjectDescriptor> entities) {
    StringBuilder out = new StringBuilder(header(ns, "support.hpp"));
    if (hasGeneratedBootstrap(entities)) {
      line(out, "namespace generated_detail {");
      for (ObjectDescriptor entity : entities) {
        line(out, "struct " + typeName(entity) + "BootstrapRecipe;");
      }
      line(out, "}");
    }
    line(out, "namespace generated_detail {");
    for (ObjectDescriptor entity : entities) { line(out, "struct " + typeName(entity) + "SampleRecipe;"); }
    line(out, "}");
    Set<FieldDescriptor> businessFields = java.util.Collections.newSetFromMap(new java.util.IdentityHashMap<>());
    for (ObjectDescriptor od : entities) {
      line(out, "struct " + typeName(od) + "; class " + typeName(od) + "Checker;");
    }
    for (ObjectDescriptor od : entities) {
      for (FieldDescriptor field : fields(od)) {
        if (CppBusinessIdMetadata.isBusinessId(field) && businessFields.add(field)) {
          businessIdType(out, field);
        }
      }
    }
    for (ObjectDescriptor od : entities) {
      String name = typeName(od);
      line(out, "struct " + name + " : generated_detail::Model<" + name + "> {");
      line(
          out,
          "using Base = generated_detail::Model<" + name + ">; friend class " + name + "Checker;");
      line(out, "static constexpr std::string_view ENTITY_NAME = " + quote(name) + ";");
      line(out, "friend struct generated_detail::" + name + "SampleRecipe;");
      if (hasGeneratedBootstrap(entities)) {
        line(out, "friend struct generated_detail::" + name + "BootstrapRecipe;");
      }
      List<FieldDescriptor> identityFields = od.getFields().stream()
          .filter(field -> field.isId() || field.isVersion()).toList();
      line(out, "static constexpr std::array<std::string_view, " + identityFields.size()
          + "> QUERY_IDENTITY_FIELDS{" + identityFields.stream().map(field -> quote(canonical(field)))
              .collect(java.util.stream.Collectors.joining(", ")) + "};");
      List<FieldDescriptor> projectionFields = descriptorFields(od);
      if (projectionFields.stream().anyMatch(field -> !canonical(field).equals(
          RustFieldDescriptorNaming.rustStorageMemberName(field)))) {
        line(out, "static constexpr std::array<std::string_view, " + projectionFields.size()
            + "> QUERY_PROJECTION_FIELDS{" + projectionFields.stream().map(field -> quote(canonical(field)))
                .collect(java.util.stream.Collectors.joining(", ")) + "};");
      }
      line(out, "private:");
      for (FieldDescriptor fd : fields(od)) {
        line(out, storageType(fd) + " " + fieldName(fd) + "_;");
      }
      for (FieldDescriptor fd :
          fields(od).stream().filter(FieldDescriptor::isObjectProperty).toList()) {
        line(
            out,
            "detail::ScopedBox<"
                + typeName(((ObjectType) fd.getFieldType()).getRefer())
                + "> "
                + relationName(fd)
                + "_;");
      }
      for (ReverseRelation rel : od.getReverseRelations()) {
        line(
            out,
            (ReverseRelationNaming.oneToOne(rel) ? "detail::ScopedBox<" : "SmartList<")
                + typeName(rel.getChild())
                + "> "
                + relationName(rel)
                + "_;");
      }
      line(out, "public:");
      line(out, name + "(std::allocator_arg_t, Allocator);");
      line(out, name + "(std::allocator_arg_t, Allocator, const " + name + "&);");
      line(
          out,
          name
              + "(std::allocator_arg_t, Allocator a, "
              + name
              + "&& other) : "
              + name
              + "(std::allocator_arg, a, std::as_const(other)) {} ");
      // The allocator-aware move delegates to copy into the destination below.
      line(out, name + "(const " + name + "&) = delete;");
      line(out, name + "(" + name + "&&) noexcept;");
      line(out, "~" + name + "();");
      line(out, "static EntityDescriptor entity_descriptor(Memory);");
      emitFieldLayout(out, od);

      line(out, "static Result<" + name + ", EntityError> from_compact_row(Memory, CompactRow);");
      line(out, "std::optional<Json> borrowed_json(Memory, EntityJsonTraversal&) const;");
      line(out, "MutationValues into_values() &&;");
      line(out, "void attachRuntimeStateRecursive(const EntityRuntimeState&);");
      for (FieldDescriptor fd : fields(od)) {
        String field = fieldName(fd);
        boolean storedOnly = fd.getBooleanAttribute("optional") || baseType(fd).equals("Json");
        line(
            out,
            (storedOnly ? "const " + storageType(fd) + "&" : applicationType(fd))
                + " "
                + field
                + "() const { return "
                + (storedOnly
                    ? field + "_"
                    : (CppBusinessIdMetadata.isBusinessId(fd)
                            ? "GeneratedBusinessIdAccess::from_canonical<"
                                + applicationType(fd)
                                + ">("
                                + "memory_resource(), "
                            : "")
                        + "detail::EntityRuntimeAccess::current_field(root, entity_key(), "
                        + quote(canonical(fd))
                        + ", "
                        + field
                        + "_)"
                        + (CppBusinessIdMetadata.isBusinessId(fd) ? ")" : ""))
                + "; }");
        if (fd.isId()) {
          line(out, storageType(fd) + " id_for_runtime() const { return " + field + "_; }");
        }
        line(
            out,
            "std::optional<Value> "
                + camel("changed_" + field)
                + "() const { return root.get(entity_key(), "
                + quote(canonical(fd))
                + "); }");
        line(
            out,
            "eval::EvalResult<"
                + applicationType(fd)
                + "> "
                + camel("eval_" + field)
                + "() const { return detail::EntityRuntimeAccess::eval_field<"
                + applicationType(fd)
                + ">(memory_resource(), load_state, "
                + quote(canonical(fd))
                + ", [this] { return detail::clone_in(memory_resource(), "
                + field
                + "()); }); }");
        if (fd.isContextRoot() || fd.isConstantObjectField()) {
          line(out, "private: // Scoped and constant assignments belong to generated runtime code.");
        }
        line(out, name + "& update_" + field + "(" + argumentType(fd) + " value) {");
        boolean textField = !CppBusinessIdMetadata.isBusinessId(fd) && baseType(fd).equals("String");
        if (textField) {
          line(out, "detail::EntityRuntimeAccess::update_text(root, entity_key(), "
              + quote(canonical(fd)) + ", " + field + "_, value);");
        } else {
          if (CppBusinessIdMetadata.isBusinessId(fd)) {
            line(out, field + "_.assign(value.asStr());");
          } else {
            line(out, field + "_ = detail::clone_in(memory_resource(), value);");
          }
          line(out, "root.set(entity_key(), " + quote(canonical(fd))
              + ", generated_detail::encode(memory_resource(), " + field + "_));");
        }
        line(out, "load_state.mark_loaded(" + quote(canonical(fd))
            + ", &detail::ContextArena::from_memory(memory_resource()).loaded_snapshots()).value();"
            + " return *this; }");
        if (fd.isContextRoot() || fd.isConstantObjectField()) {
          line(out, "public:");
        }
        if (fd.isVersion()) {
          line(out, "std::int64_t version_value() const { return " + field + "_; }");
        }
      }
      for (FieldDescriptor field : fields(od)) {
        if (!field.isConstantObjectField()) { continue; }
        for (Candidate candidate : candidates(field)) {
          String suffix = candidate.getRustCandidateMethodValue();
          line(out, name + "& " + camel("update_" + relationName(field) + "_to_" + suffix)
              + "() { return " + camel("update_" + fieldName(field)) + "("
              + candidateLiteral(field, candidate) + "); }");
          line(out, "bool " + camel(relationName(field) + "_is_" + suffix)
              + "() const { return " + camel(fieldName(field)) + "() == "
              + candidateLiteral(field, candidate) + "; }");
        }
      }
      for (FieldDescriptor fd :
          fields(od).stream().filter(FieldDescriptor::isObjectProperty).toList()) {
        String target = typeName(((ObjectType) fd.getFieldType()).getRefer());
        line(out, "const " + target + "* " + relationName(fd) + "() const;");
        if (fd.isContextRoot() || fd.isConstantObjectField()) {
          line(out, "private:");
        }
        line(out, name + "& update_" + relationName(fd) + "(const " + target + "& value);");
        if (fd.isContextRoot() || fd.isConstantObjectField()) {
          line(out, "public:");
        }
        relationEvalDeclaration(out, relationName(fd), target, false);
      }
      for (ReverseRelation rel : od.getReverseRelations()) {
        String target = typeName(rel.getChild()), member = relationName(rel);
        if (ReverseRelationNaming.oneToOne(rel)) {
          line(out, "const " + target + "* " + member + "() const;");
        } else {
          line(out, "const SmartList<" + target + ">& " + member + "() const;");
          line(out, "SmartList<" + target + ">& " + member + "();");
        }
        boolean many = !ReverseRelationNaming.oneToOne(rel);
        relationEvalDeclaration(out, member, target, many);
        line(
            out,
            "RelationHandle<"
                + (many ? "SmartList<" + target + ">" : target)
                + "> "
                + camel(member + "_handle")
                + "() const;");
      }
      line(out, "};");
    }
    for (ObjectDescriptor od : entities) {
      modelDefinitions(out, od);
    }
    line(out, "}");
    return camelModelMethods(out.toString(), entities);
  }

  private void businessIdType(StringBuilder out, FieldDescriptor field) {
    String name = CppBusinessIdMetadata.typeName(field);
    line(
        out,
        "namespace generated_detail { struct "
            + name
            + "Definition { static constexpr std::string_view field_name = "
            + quote(FieldDescriptorNaming.canonicalPropertyName(field))
            + ";");
    line(out, "static constexpr std::string_view type_name = " + quote(name) + ";");
    line(
        out,
        "static BusinessIdDefinition definition(Memory r) { BusinessIdDefinition value("
            + "std::allocator_arg, Allocator(r), field_name, "
            + quote(CppBusinessIdMetadata.prefix(field))
            + ", "
            + quote(
                CppBusinessIdMetadata.attribute(
                    field, "namespace", field.getObjectDescriptor().getName()))
            + "); value.profile = "
            + quote(CppBusinessIdMetadata.profile(field))
            + "; value.split_by_date = "
            + Boolean.parseBoolean(CppBusinessIdMetadata.attribute(field, "splitbydate", "true"))
            + "; value.preserve_digits = "
            + CppBusinessIdMetadata.digits(field)
            + "; value.separator = "
            + quote(CppBusinessIdMetadata.attribute(field, "separator", "-"))
            + "; return value; } }; } using "
            + name
            + " = GeneratedBusinessId<generated_detail::"
            + name
            + "Definition>;");
  }

  private void relationEvalDeclaration(
      StringBuilder out, String member, String target, boolean many) {
    String payload = (many ? "EntityListBorrow<" : "EntityBorrow<") + target + ">";
    line(out, "eval::EvalResult<" + payload + "> " + camel("eval_" + member) + "() const;");
  }

  private void relationEvaluations(StringBuilder out, ObjectDescriptor od) {
    String name = typeName(od);
    for (FieldDescriptor field : fields(od)) {
      if (!field.isObjectProperty()) {
        continue;
      }
      String target = typeName(((ObjectType) field.getFieldType()).getRefer());
      String member = relationName(field), identity = relationIdentity(field);
      String knownNull =
          field.getBooleanAttribute("optional")
              ? "is_loaded(" + quote(canonical(field)) + ") && !" + fieldName(field) + "()"
              : "false";
      line(
          out,
          "inline eval::EvalResult<EntityBorrow<"
              + target
              + ">> "
              + name
              + "::"
              + camel("eval_" + member)
              + "() const { return GeneratedRelationAccess::object("
              + "memory_resource(), "
              + quote(identity)
              + ", "
              + member
              + "(), "
              + knownNull
              + "); }");
    }
    for (ReverseRelation relation : od.getReverseRelations()) {
      String target = typeName(relation.getChild()), member = relationName(relation), identity = relationIdentity(relation);
      boolean many = !ReverseRelationNaming.oneToOne(relation);
      String handle = camel(member + "_handle");
      line(
          out,
          "inline RelationHandle<"
              + (many ? "SmartList<" + target + ">" : target)
              + "> "
              + name
              + "::"
              + handle
              + "() const { return root."
              + (many ? "relation_list" : "relation_option")
              + "<"
              + target
              + ">(ENTITY_NAME, id(), "
              + quote(identity)
              + "); }");
      line(
          out,
          "inline eval::EvalResult<"
              + (many ? "EntityListBorrow<" : "EntityBorrow<")
              + target
              + ">> "
              + name
              + "::"
              + camel("eval_" + member)
              + "() const { return "
              + (many
                  ? "GeneratedRelationAccess::list(*this, " + member + "(), " + quote(identity)
                  : "GeneratedRelationAccess::object(memory_resource(), "
                      + quote(identity)
                      + ", "
                      + member
                      + "(), "
                      + handle
                      + "().is_empty()")
              + "); }");
    }
  }

  private void emitFieldLayout(StringBuilder out, ObjectDescriptor od) {
    List<FieldDescriptor> fixed = CppFieldLayoutMetadata.fields(od);
    line(
        out,
        "static constexpr std::string_view FIELD_LAYOUT_REVISION = "
            + quote(CppFieldLayoutMetadata.revision(od))
            + ";");
    line(out, "static Result<FieldLayout, String> create_field_layout(Memory r) {");
    line(out, "const std::array<FieldLayout::Index, " + fixed.size() + "> indexes{{");
    for (int i = 0; i < fixed.size(); ++i) {
      line(
          out,
          "{" + quote(FieldDescriptorNaming.canonicalPropertyName(fixed.get(i))) + ", " + i + "},");
    }
    line(out, "}}; const std::array<FieldLayout::Mapping, " + fixed.size() + "> mappings{{");
    for (FieldDescriptor field : fixed) {
      line(
          out,
          "{"
              + quote(FieldDescriptorNaming.canonicalPropertyName(field))
              + ", "
              + quote(RustFieldDescriptorNaming.rustStorageMemberName(field))
              + ", "
              + quote(FieldDescriptorNaming.columnName(field))
              + "},");
    }
    line(out, "}}; const std::array<std::string_view, " + fixed.size() + "> members{{");
    for (FieldDescriptor field : fixed) {
      line(out, quote(RustFieldDescriptorNaming.rustStorageMemberName(field)) + ",");
    }
    List<String> relations = new ArrayList<>();
    for (FieldDescriptor field : fields(od)) {
      if (field.isObjectProperty()) {
        relations.add(relationIdentity(field));
      }
    }
    for (ReverseRelation relation : od.getReverseRelations()) {
      relations.add(relationIdentity(relation));
    }
    line(
        out,
        "}}; const std::array<std::string_view, "
            + relations.size()
            + "> relations{{"
            + String.join(",", relations.stream().map(CppCoreGenerator::quote).toList())
            + "}};");
    line(
        out,
        "return FieldLayout::from_generated(r, ENTITY_NAME, FIELD_LAYOUT_REVISION, indexes,"
            + " mappings, relations, members); }");
    line(
        out,
        "static const FieldLayout& field_layout(Memory r) { return"
            + " detail::ContextArena::from_memory(r).field_layout<"
            + typeName(od)
            + ">(); }");
  }

  private void relationAccessors(StringBuilder out, ObjectDescriptor od) {
    String name = typeName(od);
    for (FieldDescriptor field : fields(od)) {
      if (!field.isObjectProperty()) {
        continue;
      }
      String target = typeName(((ObjectType) field.getFieldType()).getRefer());
      String member = relationName(field), path = quote(relationIdentity(field));
      String foreign = fieldName(field) + "()";
      String resolved =
          field.getBooleanAttribute("optional")
              ? "auto foreign = "
                  + foreign
                  + "; return foreign ? root.resolve_entity<"
                  + target
                  + ">(*foreign) : nullptr;"
              : "return root.resolve_entity<" + target + ">(" + foreign + ");";
      line(
          out,
          "inline const "
              + target
              + "* "
              + name
              + "::"
              + member
              + "() const { if ("
              + member
              + "_) { return "
              + member
              + "_.get(); } if (!is_loaded("
              + path
              + ")) { return nullptr; } auto* view = root.resolve_relation_option<"
              + target
              + ">(ENTITY_NAME, id(), "
              + path
              + "); if (view) { return *view ? &**view : nullptr; } "
              + resolved
              + " }");
    }
    for (ReverseRelation relation : od.getReverseRelations()) {
      String target = typeName(relation.getChild()),
          member = relationName(relation),
          path = quote(relationIdentity(relation));
      if (ReverseRelationNaming.oneToOne(relation)) {
        line(
            out,
            "inline const "
                + target
                + "* "
                + name
                + "::"
                + member
                + "() const { if ("
                + member
                + "_) { return "
                + member
                + "_.get(); } return root.relation_option<"
                + target
                + ">(ENTITY_NAME, id(), "
                + path
                + ").value(); }");
      } else {
        line(
            out,
            "inline const SmartList<"
                + target
                + ">& "
                + name
                + "::"
                + member
                + "() const { if ("
                + member
                + "_.is_loaded) { return "
                + member
                + "_; } auto view = root.relation_list<"
                + target
                + ">(ENTITY_NAME, id(), "
                + path
                + "); return view.value() ? *view.value() : "
                + member
                + "_; }");
        line(
            out,
            "inline SmartList<"
                + target
                + ">& "
                + name
                + "::"
                + member
                + "() { if (!"
                + member
                + "_.is_loaded) { auto view = root.relation_list<"
                + target
                + ">(ENTITY_NAME, id(), "
                + path
                + "); if (view.value()) { "
                + member
                + "_ = detail::clone_in(memory_resource(), *view.value()); } } return "
                + member
                + "_; }");
      }
    }
  }

  private void jsonProjection(StringBuilder out, ObjectDescriptor od) {
    String name = typeName(od);
    line(out, "inline std::optional<Json> " + name + "::borrowed_json(Memory r, EntityJsonTraversal& traversal) const {");
    line(out, "GeneratedEntityJson projection(r, traversal, ENTITY_NAME, this, root, id_for_runtime());");
    for (FieldDescriptor field : fields(od)) {
      line(out, "projection.field(" + quote(RustFieldDescriptorNaming.rustStorageMemberName(field))
          + ", [&] { return generated_detail::encode(r, " + fieldName(field) + "_); }, load_state.is_loaded("
          + quote(RustFieldDescriptorNaming.rustStorageMemberName(field)) + "), "
          + (field.isId() || field.isVersion() ? "true" : "false") + ");");
    }
    line(out, "projection.dynamic(dynamic);");
    for (FieldDescriptor field : fields(od)) {
      if (field.isObjectProperty()) {
        String member = relationName(field), identity = relationIdentity(field);
        line(out, "projection.forward<" + typeName(((ObjectType) field.getFieldType()).getRefer())
            + ">(" + quote(identity) + ", " + member + "_ ? &*" + member
            + "_ : nullptr, load_state.is_loaded(" + quote(identity)
            + "), generated_detail::encode(r, " + fieldName(field) + "_));");
      }
    }
    for (ReverseRelation relation : od.getReverseRelations()) {
      String identity = relationIdentity(relation);
      line(out, "projection." + (ReverseRelationNaming.oneToOne(relation) ? "reverse_one" : "reverse_many")
          + "<" + typeName(relation.getChild()) + ">(" + quote(identity)
          + ", load_state.is_loaded(" + quote(identity) + "));");
    }
    line(out, "return projection.finish(dynamic_field_values()); }");
  }

  private void modelDefinitions(StringBuilder out, ObjectDescriptor od) {
    relationAccessors(out, od);
    relationEvaluations(out, od);
    jsonProjection(out, od);
    String name = typeName(od);
    line(out, "inline void " + name
        + "::attachRuntimeStateRecursive(const EntityRuntimeState& target) {");
    line(out, "root.attach_runtime_state(target);");
    for (FieldDescriptor field : fields(od)) {
      if (field.isObjectProperty()) {
        String member = relationName(field) + "_";
        line(out, "if (" + member + ") { " + member
            + "->attachRuntimeStateRecursive(target); }");
      }
    }
    line(out, "}");
    StringBuilder init = new StringBuilder(": Base(std::allocator_arg, a)");
    StringBuilder copy = new StringBuilder(": Base(std::allocator_arg, a, other)");
    for (FieldDescriptor fd : fields(od)) {
      String member = fieldName(fd) + "_";
      boolean clockDefault = "Timestamp".equals(baseType(fd))
          && "teaql_core::time::Timestamp::now()".equals(RustFieldDescriptorNaming.rustDefaultValue(fd));
      init.append(", ")
          .append(member)
          .append(clockDefault ? "(Timestamp::now())" : "(generated_detail::default_value<"
              + storageType(fd) + ">(a.resource()))");
      copy.append(", ")
          .append(member)
          .append("(detail::clone_in(a.resource(), other.")
          .append(member)
          .append("))");
    }
    for (FieldDescriptor fd :
        fields(od).stream().filter(FieldDescriptor::isObjectProperty).toList()) {
      String member = relationName(fd) + "_";
      init.append(", ")
          .append(member)
          .append("(nullptr, detail::ScopedDelete<")
          .append(typeName(((ObjectType) fd.getFieldType()).getRefer()))
          .append(">{a.resource()})");
      copy.append(", ")
          .append(member)
          .append("(generated_detail::copy_box(a.resource(), other.")
          .append(member)
          .append("))");
    }
    for (ReverseRelation rel : od.getReverseRelations()) {
      String member = relationName(rel) + "_";
      if (ReverseRelationNaming.oneToOne(rel)) {
        init.append(", ")
            .append(member)
            .append("(nullptr, detail::ScopedDelete<")
            .append(typeName(rel.getChild()))
            .append(">{a.resource()})");
        copy.append(", ")
            .append(member)
            .append("(generated_detail::copy_box(a.resource(), other.")
            .append(member)
            .append("))");
      } else {
        init.append(", ").append(member).append("(std::allocator_arg, a)");
        copy.append(", ")
            .append(member)
            .append("(std::allocator_arg, a, other.")
            .append(member)
            .append(")");
      }
    }
    line(
        out,
        "inline " + name + "::" + name + "(std::allocator_arg_t, Allocator a) " + init + " {}");
    line(
        out,
        "inline "
            + name
            + "::"
            + name
            + "(std::allocator_arg_t, Allocator a, const "
            + name
            + "& other) "
            + copy
            + " {}");
    line(out, "inline " + name + "::" + name + "(" + name + "&&) noexcept = default;");
    line(out, "inline " + name + "::~" + name + "() = default;");
    line(out, "inline EntityDescriptor " + name + "::entity_descriptor(Memory r) {");
    line(
        out,
        "EntityDescriptor d(std::allocator_arg, Allocator(r), ENTITY_NAME); d.table("
            + quote(od.getTableName())
            + ");");
    if (od.getDataService() != null) {
      line(out, "d.service(" + quote(od.getDataService().getName()) + ");");
    }
    for (FieldDescriptor fd : descriptorFields(od)) {
      String flags =
          (fd.isId() ? ".id()" : fd.isVersion() ? ".version()" : "")
              + (!fd.getBooleanAttribute("optional") ? ".not_null()" : "");
      line(
          out,
          "{ auto& property = d.property("
              + quote(RustFieldDescriptorNaming.rustStorageMemberName(fd))
              + ", DataType::"
              + dataType(fd)
              + ", "
              + quote(columnName(fd))
              + ")"
              + flags
              + ";");
      String inputColumn = CppJsonInputMetadata.column(fd);
      String physicalColumn = columnName(fd).isEmpty() ? canonical(fd) : columnName(fd);
      if (!inputColumn.equals(physicalColumn)) {
        line(out, "property.json_column_name.emplace(" + CppJsonInputMetadata.cppView(inputColumn) + ", r);");
      }
      String maxLength = fd.getAttributeValue("max");
      if (baseType(fd).equals("String")
          && !fd.getBooleanAttribute("isText")
          && maxLength != null
          && maxLength.matches("[1-9][0-9]*")) {
        line(out, "property.with_max_length(" + maxLength + ");");
      }
      String sqlType = fd.getAttributeValue(Attributes.SQL_TYPE);
      if (sqlType != null) {
        var numeric =
            Pattern.compile(
                    "(?i)^\\s*(?:NUMERIC|DECIMAL)\\s*\\(\\s*(\\d+)\\s*,\\s*(\\d+)\\s*\\)\\s*$")
                .matcher(sqlType);
        if (numeric.matches()) {
          line(
              out,
              "property.with_numeric_precision("
                  + numeric.group(1)
                  + ").with_numeric_scale("
                  + numeric.group(2)
                  + ");");
        }
      }
      line(out, "(void)property; }");
    }
    for (FieldDescriptor fd :
        fields(od).stream().filter(FieldDescriptor::isObjectProperty).toList()) {
      descriptorRelation(
          out,
          relationIdentity(fd),
          typeName(((ObjectType) fd.getFieldType()).getRefer()),
          canonical(fd),
          "id",
          false);
    }
    for (ReverseRelation rel : od.getReverseRelations()) {
      descriptorRelation(
          out,
          relationIdentity(rel),
          typeName(rel.getChild()),
          "id",
          canonical(rel.getProperty()),
          !ReverseRelationNaming.oneToOne(rel));
    }
    line(out, "d.mask_fields({" + String.join(",",
        CppFieldLayoutMetadata.auditMaskFields(od).stream().map(FieldDescriptorNaming::canonicalPropertyName)
            .map(CppCoreGenerator::quote).toList()) + "});");
    String auditLimit = CppFieldLayoutMetadata.auditValueMaxLen(od);
    if (auditLimit != null) {
      boolean wide = new java.math.BigInteger(auditLimit).bitLength() > 32;
      if (wide) {
        line(out, "static_assert(" + auditLimit + "ULL <= static_cast<unsigned long long>(static_cast<std::size_t>(-1)), \"audit_value_max_len exceeds target usize\");");
      }
      line(out, "d.audit_max_length(" + auditLimit + (wide ? "ULL" : "") + ");");
    }
    line(out, "return d; }");
    line(
        out,
        "inline Result<"
            + name
            + ", EntityError> "
            + name
            + "::from_compact_row(Memory r, CompactRow row) {");
    line(
        out,
        "using Outcome = Result<"
            + name
            + ", EntityError>; "
            + name
            + " result(std::allocator_arg, Allocator(r)); auto captured = detail::EntityRuntimeAccess::capture_dynamic_values(result.dynamic, row, field_layout(r)); if (!captured) { return Outcome::err(r, std::move(captured).error()); }");
    for (FieldDescriptor fd : fields(od)) {
      String variable = fieldName(fd) + "_lookup";
      line(out, "auto " + variable + " = GeneratedRelationAccess::lookupField(r, row, ENTITY_NAME, "
          + quote(canonical(fd)) + ", " + quote(columnName(fd)) + ", " + fd.isObjectProperty() + ");");
      line(out, "if (!" + variable + ") { return Outcome::err(r, std::move(" + variable + ").error()); }");
    }
    for (FieldDescriptor fd : fields(od)) {
      String field = fieldName(fd);
      line(
          out,
          "auto "
              + field
              + "_value = generated_detail::decode<"
              + storageType(fd)
              + ">(r, "
              + field
              + "_lookup.value().value, ENTITY_NAME, "
              + quote(canonical(fd))
              + ");");
      line(
          out,
          "if (!"
              + field
              + "_value) { return Outcome::err(r, std::move("
              + field
              + "_value).error()); }");
      line(out, "result." + field + "_ = std::move(" + field + "_value).value();");
    }
    for (FieldDescriptor fd :
        fields(od).stream().filter(FieldDescriptor::isObjectProperty).toList()) {
      decodeRelation(
          out,
          name,
          relationName(fd),
          relationIdentity(fd),
          typeName(((ObjectType) fd.getFieldType()).getRefer()));
    }
    // Source reverse relations are installed runtime views, not struct fields
    // reconstructed from arbitrary raw columns. Keep the local fallback empty.
    line(
        out,
        "result.load_state ="
            + " row.indexed_load_state(detail::ContextArena::from_memory(r).loaded_snapshots(),"
            + " field_layout(r));");
    for (FieldDescriptor fd : fields(od)) {
      if (fd.isObjectProperty()) {
        String variable = fieldName(fd) + "_lookup.value()";
        line(out, "if (" + variable + ".alias_present) { auto& pool = detail::ContextArena::from_memory(r).loaded_snapshots();");
        line(out, "if (!" + variable + ".object_alias && !row.is_loaded_relation(" + quote(columnName(fd)) + ")) { result.load_state.mark_unloaded(" + quote(relationIdentity(fd)) + ", &pool).value(); }");
        line(out, "result.load_state.mark_loaded(" + quote(canonical(fd)) + ", &pool).value(); }");
      }
    }
    line(out, "result.root.set_original_compact_row(ENTITY_NAME, row); return Outcome::ok(r, std::move(result)); }");
    line(
        out,
        "inline MutationValues "
            + name
            + "::into_values() && { auto r = memory_resource(); MutationValues values(r);");
    for (FieldDescriptor fd : fields(od)) {
      line(
          out,
          "values.fields.emplace(String("
              + quote(canonical(fd))
              + ", r), generated_detail::encode(r, "
              + fieldName(fd)
              + "_));");
    }
    line(out, "detail::EntityRuntimeAccess::retain_loaded_native_values(values, load_state);");
    for (FieldDescriptor fd :
        fields(od).stream().filter(FieldDescriptor::isObjectProperty).toList()) {
      injectRelation(out, relationName(fd), relationIdentity(fd), false);
    }
    for (ReverseRelation rel : od.getReverseRelations()) {
      injectRelation(out, relationName(rel), relationIdentity(rel), !ReverseRelationNaming.oneToOne(rel));
    }
    line(out, "inject_runtime(values); return values; }");
    for (FieldDescriptor fd :
        fields(od).stream().filter(FieldDescriptor::isObjectProperty).toList()) {
      String target = typeName(((ObjectType) fd.getFieldType()).getRefer()),
          relation = relationName(fd);
      line(
          out,
          "inline "
              + name
              + "& "
              + name
              + "::update_"
              + relation
              + "(const "
              + target
              + "& value) { "
              + relation
              + "_ = detail::make_box<"
              + target
              + ">(memory_resource(), value); update_"
              + fieldName(fd)
              + "(value.id()); return *this; }");
    }
  }

  private void descriptorRelation(
      StringBuilder out, String name, String target, String local, String foreign, boolean many) {
    line(
        out,
        "{ auto& relation = d.relation("
            + quote(name)
            + ", "
            + quote(target)
            + "); relation.local_key = "
            + quote(local)
            + "; relation.foreign_key = "
            + quote(foreign)
            + "; relation.many = "
            + many
            + "; }");
  }

  private void decodeRelation(StringBuilder out, String entity, String member, String identity, String target) {
    String variable = member + "_decoded";
    line(out, "auto " + variable + " = GeneratedRelationAccess::decodeObject<" + target
        + ">(r, row.get(" + quote(identity) + "));");
    line(out, "if (!" + variable + ") { return Outcome::err(r, std::move(" + variable + ").error()); }");
    line(out, "if (" + variable + ".value()) { result." + member + "_ = detail::make_box<" + target
        + ">(r, std::move(*" + variable + ".value())); }");
  }

  private void injectRelation(StringBuilder out, String member, String identity, boolean many) {
    if (many) {
      line(
          out,
          "if (auto relation = std::move("
              + member
              + "_).into_value()) { values.fields.emplace(String("
              + quote(identity)
              + ", r), std::move(*relation)); }");
    } else {
      line(
          out,
          "if ("
              + member
              + "_) { values.fields.emplace(String("
              + quote(identity)
              + ", r), Value(r, std::move(*"
              + member
              + "_).into_values().fields)); }");
    }
  }

  private String queries(String ns, List<ObjectDescriptor> entities) {
    StringBuilder out = new StringBuilder(header(ns, "models.hpp"));
    line(out, "namespace generated_detail {");
    for (ObjectDescriptor od : entities) {
      line(out, "struct " + typeName(od) + "DynamicJsonRecipe;");
    }
    for (ObjectDescriptor od : entities) {
      line(out, "struct " + typeName(od) + "DynamicJsonRecipe { using Model = " + typeName(od) + ";");
      line(out, "static std::optional<std::string_view> self_field(std::string_view field) {");
      for (FieldDescriptor field : fields(od).stream().filter(FieldDescriptor::isSimpleProperty).toList()) {
        line(out, "if (field == " + quote(canonical(field)) + ") { return " + quote(canonical(field)) + "; }");
      }
      for (FieldDescriptor field : fields(od).stream().filter(FieldDescriptor::isObjectProperty).toList()) {
        String member = RustFieldDescriptorNaming.rustMemberName(field);
        line(out, "if (field == " + quote(member) + " || field == " + quote(canonical(field)) + ") { return " + quote(canonical(field)) + "; }");
      }
      line(out, "return std::nullopt; }");
      line(out, "template<class Query> static void apply_chain(Query& query, std::string_view head, std::string_view tail, const Json& value);");
      line(out, "};");
    }
    // Template relation bodies follow every recipe declaration; cycles are valid.
    for (ObjectDescriptor od : entities) {
      line(out, "template<class Query> void " + typeName(od) + "DynamicJsonRecipe::apply_chain(Query& query, std::string_view head, std::string_view tail, const Json& value) {");
      line(out, "(void)query; (void)head; (void)tail; (void)value;");
      for (FieldDescriptor field : fields(od).stream().filter(FieldDescriptor::isObjectProperty).toList()) {
        ObjectDescriptor target = ((ObjectType) field.getFieldType()).getRefer();
        line(out, "if (head == " + quote(RustFieldDescriptorNaming.rustMemberName(field)) + ") { apply_generated_dynamic_json_relation<" + typeName(target) + "DynamicJsonRecipe>(query, " + quote(canonical(field)) + ", \"id\", tail, value, head); return; }");
      }
      for (ReverseRelation relation : od.getReverseRelations()) {
        line(out, "if (head == " + quote(RustReverseRelationNaming.rustMemberName(relation)) + ") { apply_generated_dynamic_json_relation<" + typeName(relation.getChild()) + "DynamicJsonRecipe>(query, \"id\", " + quote(canonical(relation.getProperty())) + ", tail, value, head); return; }");
      }
      line(out, "}");
    }
    line(out, "}");
    for (ObjectDescriptor od : entities) {
      line(out, "template <bool Purposed = false, Entity Result = " + typeName(od) + "> class " + typeName(od) + "Request;");
    }
    for (ObjectDescriptor od : entities) {
      String name = typeName(od), request = name + "Request";
      StringBuilder friends = new StringBuilder();
      for (ObjectDescriptor other : entities) {
        friends
            .append("template <bool, Entity> friend class ")
            .append(typeName(other))
            .append("Request;\n");
      }
      line(
          out,
          "template <bool Purposed, Entity Result> class "
              + request
              + " {\n"
              + friends
              + "public:\n"
              + "using Query = EntityQuery<"
              + name
              + ", DataServiceExecutor, Purposed, Result>;\n"
              + "private: Query query_;\npublic:\n"
              + "explicit "
              + request
              + "(UserContext& user_context, bool minimal = false, bool live_rows = true) requires (!Purposed) :"
              + " query_(user_context, minimal, live_rows) {}\n"
              + "explicit "
              + request
              + "(Query value) : query_(std::move(value)) {}\n"
              + "Memory memory_resource() const { return query_.memory_resource(); }\n"
              + "const SelectQuery& query() const { return query_.query(); }\n"
              + "SelectQuery coreQuery() const requires (!Purposed) { return query_.coreQuery(); }\n"
              + "const Query& runtimeQuery() const requires (!Purposed) { return query_; }\n"
              + "request::QuerySelection selection() const requires (!Purposed) { return query_.selection(); }\n"
              + "auto relationSelections() const requires (!Purposed) { return query_.relationSelections(); }\n"
              + "auto relationFilters() const requires (!Purposed) { return query_.relationFilters(); }\n"
              + "auto childEnhancements() const requires (!Purposed) { return query_.childEnhancements(); }\n"
              + "auto queryOptions() const requires (!Purposed) { return query_.queryOptions(); }\n"
              + "SelectQuery intoQuery() && requires (!Purposed) { return std::move(query_).intoQuery(); }\n"
              + request
              + "<true, Result> purpose(std::string_view text) const& { return "
              + request
              + "<true, Result>(query_.purpose(text)); }\n"
              + request
              + "<true, Result> purpose(std::string_view text) && { return "
              + request
              + "<true, Result>(std::move(query_).purpose(text)); }");
      line(out, "template <Entity Return> " + request + "<Purposed, Return> returnType() const& { return "
          + request + "<Purposed, Return>(query_.template returnType<Return>()); }");
      line(out, "template <Entity Return> " + request + "<Purposed, Return> returnType() && { return "
          + request + "<Purposed, Return>(std::move(query_).template returnType<Return>()); }");
      for (String[] method :
          List.of(
              new String[] {"comment", "std::string_view"},
              new String[] {"filter", "const Expr&"},
              new String[] {"selectDynamicFields", "const DynamicFieldSelection&"},
              new String[] {"matchTypes", "std::span<const Value>"},
              new String[] {"andFilter", "const Expr&"},
              new String[] {"orFilter", "const Expr&"},
              new String[] {"limit", "std::uint64_t"},
              new String[] {"offset", "std::uint64_t"},
              new String[] {"hardLimit", "std::uint64_t"},
              new String[] {"stream", "std::size_t"})) {
        fluent(
            out,
            request,
            "",
            method[0],
            method[1] + " value",
            "value",
            "query_." + method[0] + "(value);");
      }
      fluent(out, request, "", "unlimited", "", "", "query_.unlimited();");
      fluent(out, request, "", "withDeletedRows", "", "", "query_.withDeletedRows();");
      fluent(out, request, "", "deletedRowsOnly", "", "", "query_.deletedRowsOnly();");
      fluent(out, request, "", "appendSearchCriteria", "const Expr& criteria", "criteria", "query_.appendSearchCriteria(criteria);");
      fluent(out, request, "", "appendSearchCriteria", "Ref<Expr> criteria", "criteria", "query_.appendSearchCriteria(criteria);");
      fluent(out, request,
          "template <std::ranges::input_range Inputs> requires std::constructible_from<Value, Memory, std::ranges::range_reference_t<Inputs>> ",
          "matchTypes", "Inputs&& inputs", "std::forward<Inputs>(inputs)",
          "query_.matchTypes(std::forward<Inputs>(inputs));");
      fluent(out, request, "", "filterProperty", "std::string_view left, request::FieldOperator op, std::string_view right", "left, op, right", "query_.filterProperty(left, op, right);");
      fluent(out, request, "", "pageOffset", "std::uint64_t offset, std::uint64_t size", "offset, size", "query_.pageOffset(offset, size);");
      fluent(out, request, "", "offset", "std::uint64_t offset, std::uint64_t size", "offset, size", "query_.offset(offset, size);");
      fluent(out, request, "", "offsetOnly", "std::uint64_t value", "value", "query_.offsetOnly(value);");
      fluent(out, request, "", "offsetSize", "std::uint64_t offset, std::uint64_t size", "offset, size", "query_.offsetSize(offset, size);");
      fluent(out, request, "", "top", "std::uint64_t value", "value", "query_.top(value);");
      fluent(out, request, "", "pageNumber", "std::uint64_t number, std::uint64_t size", "number, size", "query_.pageNumber(number, size);");
      fluent(out, request, "", "pageNumberDefault", "std::uint64_t number", "number", "query_.pageNumberDefault(number);");
      fluent(out, request, "", "page", "std::uint64_t number, std::uint64_t size", "number, size", "query_.page(number, size);");
      fluent(out, request, "", "pageDefault", "std::uint64_t number", "number", "query_.pageDefault(number);");
      fluent(out, request, "", "streamDefault", "", "", "query_.streamDefault();");
      fluent(out, request, "", "topNProbeParentThreshold", "std::size_t threshold", "threshold", "query_.topNProbeParentThreshold(threshold);");
      fluent(out, request, "", "rawSql", "std::string_view sql", "sql", "query_.rawSql(sql);");
      fluent(out, request, "", "rawSqlFilter", "std::string_view sql", "sql", "query_.rawSqlFilter(sql);");
      fluent(out, request, "", "createPropertyAs", "std::string_view field, std::string_view sql", "field, sql", "query_.createPropertyAs(field, sql);");
      fluent(out, request, "", "unsafeRawSql", "request::UnsafeRawSqlSegment sql", "std::move(sql)", "query_.unsafeRawSql(std::move(sql));");
      fluent(out, request, "", "unsafeRawSqlFilter", "request::UnsafeRawSqlSegment sql", "std::move(sql)", "query_.unsafeRawSqlFilter(std::move(sql));");
      fluent(out, request, "", "unsafeCreatePropertyAs", "std::string_view field, request::UnsafeRawSqlSegment sql", "field, std::move(sql)", "query_.unsafeCreatePropertyAs(field, std::move(sql));");

      for (String method : List.of("groupBy", "countAs", "aggregateCount")) {
        fluent(out, request, "", method, "std::string_view value", "value", "query_." + method + "(value);");
      }
      fluent(out, request, "", "count", "", "", "query_.count();");
      fluent(out, request, "", "aggregateWithFunction", "std::string_view field, std::string_view alias, AggregateFunction function", "field, alias, function", "query_.aggregateWithFunction(field, alias, function);");
      for (String method : List.of("aggregateCountField", "aggregateSum", "aggregateAvg", "aggregateMin", "aggregateMax", "aggregateStddev", "aggregateStddevPop", "aggregateVarSamp", "aggregateVarPop", "aggregateBitAnd", "aggregateBitOr", "aggregateBitXor")) {
        fluent(out, request, "", method, "std::string_view field, std::string_view alias", "field, alias", "query_." + method + "(field, alias);");
      }
      fluent(out, request, "", "enableAggregationCache", "", "", "query_.enableAggregationCache();");
      for (String method : List.of("enableAggregationCacheFor", "propagateAggregationCache")) {
        fluent(out, request, "", method, "std::uint64_t duration", "duration", "query_." + method + "(duration);");
      }

      fluent(out, request, "", "optimizePaginationWithIdSet", "", "", "query_.optimizePaginationWithIdSet();");
      fluent(out, request, "", "optimizePaginationWithIdSetConfig", "std::string_view name, std::uint64_t ttl, std::uint64_t max_ids", "name, ttl, max_ids", "query_.optimizePaginationWithIdSetConfig(name, ttl, max_ids);");
      fluent(out, request, "", "optimizeForContinuousPageFetch", "", "", "query_.optimizeForContinuousPageFetch();");
      fluent(out, request, "", "optimizeForContinuousPageFetchWith", "std::string_view name, std::uint64_t ttl", "name, ttl", "query_.optimizeForContinuousPageFetchWith(name, ttl);");

      fluent(out, request, "", "filterWithJson", "std::string_view value", "value",
          "apply_generated_dynamic_json<generated_detail::" + name + "DynamicJsonRecipe>(query_, value);");
      fluent(out, request, "", "withTypeGroup", "", "", "query_.withTypeGroup();");
      fluent(out, request, "template <class ChildRequest> requires requires (const ChildRequest& child) { child.runtimeQuery().selection(); } ", "enhanceChild",
          "const ChildRequest& child", "child", "query_.enhanceChild(child.runtimeQuery());");
      for (String childType : List.of("SelectQuery", "request::QuerySelection")) {
        fluent(out, request, "", "enhanceChild", "const " + childType + "& child", "child",
            "query_.enhanceChild(child);");
      }
      for (String method : List.of("matchingAnyOf", "matchAnyOf")) {
        fluent(out, request,
            "template <class ChildRequest> requires requires (const ChildRequest& child) { child.runtimeQuery().selection(); } ",
            method, "const ChildRequest& child", "child", "query_." + method + "(child.runtimeQuery());");
        for (String childType : List.of("SelectQuery", "request::QuerySelection")) {
          fluent(out, request, "", method, "const " + childType + "& child", "child", "query_." + method + "(child);");
        }
      }
      line(out, request + "& enhanceChildrenIfNeeded() &;");
      line(out, request + "&& enhanceChildrenIfNeeded() && { enhanceChildrenIfNeeded(); return std::move(*this); }");
      for (ObjectDescriptor child : od.getChildrenOds()) {
        List<ObjectDescriptor> matches = new ArrayList<>();
        matches.add(child);
        matches.addAll(child.getAllChildrenOds());
        String values = matches.stream().map(type -> "Value(memory_resource(), " + quote(typeName(type)) + ")")
            .collect(java.util.stream.Collectors.joining(", "));
        fluent(out, request, "", "is" + typeName(child), "", "",
            "const std::array types{" + values + "}; query_.matchTypes(types);");
      }
      fluent(out, request, "", "skip", "std::uint64_t value", "value", "query_.offset(value);");
      fluent(
          out,
          request,
          "",
          "searchWithText",
          "std::string_view value",
          "value",
          "query_.mutate_selection([&](SelectQuery& selection) { selection.search_with_text(value);"
              + " });");
      StringBuilder projection = new StringBuilder();
      for (FieldDescriptor fd : descriptorFields(od)) {
        projection.append("query_.select(").append(quote(canonical(fd))).append(");");
      }
      fluent(out, request, "", "selectSelf", "", "", projection.toString());
      fluent(out, request, "", "selectSelfFields", "", "", "selectSelf();");
      fluent(out, request, "", "selectSelfWithoutParent", "", "", "selectSelfFields();");
      StringBuilder all = new StringBuilder("selectSelf();");
      for (FieldDescriptor field : fields(od)) {
        if (field.isObjectProperty()) {
          all.append(camel("select_" + relationName(field))).append("();");
        }
      }
      for (ReverseRelation relation : od.getOneToOneRelations()) {
        all.append(camel("select_" + relationName(relation))).append("();");
      }
      fluent(out, request, "", "selectAll", "", "", all.toString());
      StringBuilder children = new StringBuilder("selectAll();");
      for (ReverseRelation relation : od.getOneToManyRelations()) {
        children.append(camel("select_" + relationName(relation))).append("();");
      }
      fluent(out, request, "", "selectChildren", "", "", children.toString());
      fluent(out, request, "", "selectAny", "", "", "selectChildren();");
      for (String method : List.of("executeForList", "executeForOne", "executeForFirst", "executeForCount", "executeForExists", "executeForStream")) {
        line(
            out,
            "auto& "
                + method
                + "(UserContext& user_context) const requires Purposed { return query_."
                + method
                + "(user_context); }");
      }
      line(out, "auto& executeForPage(UserContext& user_context, std::uint64_t offset, std::uint64_t limit) const requires Purposed { return query_.executeForPage(user_context, offset, limit); }");
      for (String[] alias :
          List.of(
              new String[] {"execute", "executeForOne"},
              new String[] {"executeForEntity", "executeForOne"},
              new String[] {"executeForEntityList", "executeForList"})) {
        line(
            out,
            "auto& "
                + alias[0]
                + "(UserContext& user_context) const requires Purposed { return query_."
                + alias[1]
                + "(user_context); }");
      }
      line(
          out,
          "auto& executeForRows(UserContext& user_context) const requires Purposed { return"
              + " query_.executeForRows(user_context); }");
      line(
          out,
          name
              + "& newEntity(UserContext& user_context) const requires Purposed { return"
              + " query_.newEntity(user_context); }");
      for (String method : List.of("copyTo", "copyToGlobal", "rebindGlobal")) {
        line(
            out,
            request
                + " "
                + method
                + "(UserContext& user_context) const { return "
                + request
                + "(query_."
                + method
                + "(user_context)); }");
      }
      StringBuilder methods = new StringBuilder();
      for (FieldDescriptor fd : fields(od)) {
        queryField(methods, request, fd);
      }
      for (FieldDescriptor fd :
          fields(od).stream().filter(FieldDescriptor::isObjectProperty).toList()) {
        if (candidates(fd).isEmpty()) {
          fluent(out, request, "template <request::EntityReference Reference> ",
              camel("filter_by_" + relationName(fd)), "Reference&& value", "std::forward<Reference>(value)",
              "query_.andFilter(Expr::eq(memory_resource(), " + quote(canonical(fd))
                  + ", request::entity_id_value(memory_resource(), std::forward<Reference>(value))));");
        }
        String target = typeName(((ObjectType) fd.getFieldType()).getRefer());
        relationSelectionInputs(out, request, relationName(fd), relationIdentity(fd));
        line(
            methods,
            request
                + "& select_"
                + relationName(fd)
                + "() { selection.relation("
                + quote(relationIdentity(fd))
                + "); return *this; }");
        line(
            methods,
            "template <bool P, Entity ChildResult> requires (!P) "
                + request
                + "& select_"
                + relationName(fd)
                + "_with(const "
                + target
                + "Request<P, ChildResult>& child) { selection.relation_query("
                + quote(relationIdentity(fd))
                + ", child.query()); return *this; }");
        line(
            methods,
            "template <bool P, Entity ChildResult> requires (!P) "
                + request
                + "& "
                + identifier(FieldDescriptorNaming.attributePredicatePrefixExpr(fd))
                + "(const "
                + target
                + "Request<P, ChildResult>& child) { auto r = memory_resource();"
                + " selection.and_filter(Expr::in_subquery(r, "
                + quote(canonical(fd))
                + ", "
                + target
                + "::entity_descriptor(r), child.query(), \"id\")); return *this; }");
      }
      for (FieldDescriptor field : fields(od).stream().filter(FieldDescriptor::isObjectProperty).toList()) {
        objectAnalysisInputs(out, request, field);
        objectAnalysisMethods(methods, request, field);
      }
      for (ReverseRelation relation : od.getReverseRelations()) {
        reverseMatchingInputs(out, request, relation);
        if (od.getOneToManyRelations().contains(relation)) {
          reverseAnalysisInputs(out, request, relation);
        }
        reverseAnalysisMethods(methods, request, relation, od.getOneToManyRelations().contains(relation));
      }
      for (ReverseRelation rel : od.getReverseRelations()) {
        relationSelectionInputs(out, request, relationName(rel), relationIdentity(rel));
        line(
            methods,
            request
                + "& select_"
                + relationName(rel)
                + "() { selection.relation("
                + quote(relationIdentity(rel))
                + "); return *this; }");
        line(
            methods,
            "template <bool P, Entity ChildResult> requires (!P) "
                + request
                + "& select_"
                + relationName(rel)
                + "_with(const "
                + typeName(rel.getChild())
                + "Request<P, ChildResult>& child) { selection.relation_query("
                + quote(relationIdentity(rel))
                + ", child.query()); return *this; }");
        line(
            methods,
            "template <bool P, Entity ChildResult> requires (!P) "
                + request
                + "& with_"
                + relationName(rel)
                + "(const "
                + typeName(rel.getChild())
                + "Request<P, ChildResult>& child) { auto r = memory_resource();"
                + " selection.and_filter(Expr::in_subquery(r, \"id\", "
                + typeName(rel.getChild())
                + "::entity_descriptor(r), child.query(), "
                + quote(canonical(rel.getProperty()))
                + ")); return *this; }");
      }
      adaptQueryMethods(out, request, methods.toString());
      for (FieldDescriptor field : fields(od)) {
        if (field.isObjectProperty()) {
          relationSelectionAliases(out, request, relationName(field), relationIdentity(field), true);
        }
      }
      for (ReverseRelation relation : od.getReverseRelations()) {
        relationSelectionAliases(out, request, relationName(relation), relationIdentity(relation), false);
      }
      for (FieldDescriptor fd : fields(od)) {
        queryFieldCriteria(out, request, fd);
      }
      line(out, "};");
    }
    // Define descendant construction after every Request is complete.
    for (ObjectDescriptor od : entities) {
      String request = typeName(od) + "Request";
      line(out, "template <bool Purposed, Entity Result> " + request + "<Purposed, Result>& " + request
          + "<Purposed, Result>::enhanceChildrenIfNeeded() & {");
      for (ObjectDescriptor child : od.getChildrenOds()) {
        line(out, "enhanceChild(" + typeName(child) + "Request<false>(query_.template childQuery<"
            + typeName(child) + ">()).unlimited().selectSelfFields().enhanceChildrenIfNeeded());");
      }
      line(out, "return *this; }");
    }
    line(
        out,
        "class query_factory { ContextBinding binding_; public: explicit query_factory(UserContext&"
            + " user_context) : binding_(user_context) {}");
    Set<String> entries = new HashSet<>();
    for (ObjectDescriptor od : entities) {
      String plural = camel(identifier(PluralizationUtils.pluralize(od.getName())));
      if (!entries.add(plural)) {
        throw new IllegalArgumentException("C++ Q entry collision: " + plural);
      }
      line(
          out,
          typeName(od)
              + "Request<false> "
              + plural
              + "Minimal() const { return "
              + typeName(od)
              + "Request<false>(binding_.get(), true); }");
      line(
          out,
          typeName(od)
              + "Request<false> "
              + plural
              + "() const { return "
              + typeName(od)
              + "Request<false>(binding_.get()); }");
      line(out, typeName(od) + "Request<false> " + plural + "WithChildren() const { return "
          + typeName(od) + "Request<false>(binding_.get(), true, false).unlimited().selectSelfFields().enhanceChildrenIfNeeded(); }");
    }
    line(out, "};\n}");
    return out.toString();
  }

  private static String camel(String name) {
    return NamingCase.toCamelCase(name);
  }

  private void fluent(
      StringBuilder out,
      String request,
      String template,
      String method,
      String parameters,
      String arguments,
      String body) {
    line(
        out,
        template
            + request
            + "& "
            + method
            + "("
            + parameters
            + ") & { "
            + body
            + " return *this; }");
    line(
        out,
        template
            + request
            + "&& "
            + method
            + "("
            + parameters
            + ") && { this->"
            + method
            + "("
            + arguments
            + "); return std::move(*this); }");
  }

  // Keep the complete established field predicate vocabulary; only adapt binding,
  // value categories and application casing after resolving semantic names.
  private static String cppArguments(String parameters) {
    List<String> arguments = new ArrayList<>();
    int depth = 0, start = 0;
    for (int index = 0; index <= parameters.length(); ++index) {
      char ch = index == parameters.length() ? ',' : parameters.charAt(index);
      if (ch == '<') { ++depth; }
      if (ch == '>') { --depth; }
      if (ch == ',' && depth == 0) {
        String parameter = parameters.substring(start, index).trim();
        if (!parameter.isEmpty()) {
          String name = parameter.replaceAll(".*[ &]", "");
          arguments.add(parameter.contains("UnsafeRawSqlSegment") ? "std::move(" + name + ")" : name);
        }
        start = index + 1;
      }
    }
    return String.join(", ", arguments);
  }

  private void adaptQueryMethods(StringBuilder out, String request, String source) {
    java.util.regex.Pattern pattern =
        java.util.regex.Pattern.compile(
            "(template <bool P(?:, Entity ChildResult)?> (?:requires \\(!P\\) )?)?"
                + request
                + "& ([A-Za-z_][A-Za-z_0-9]*)\\(([^)]*)\\) \\{ (.*?)return \\*this; \\}",
            java.util.regex.Pattern.DOTALL);
    java.util.regex.Matcher matcher = pattern.matcher(source);
    int consumed = 0;
    while (matcher.find()) {
      if (!source.substring(consumed, matcher.start()).isBlank()) {
        throw new IllegalStateException("Unadapted C++ query method");
      }
      String parameters = matcher.group(3);
      String arguments = cppArguments(parameters);
      if (matcher.group(4).startsWith("selection.relation_query(")) {
        fluent(out, request, matcher.group(1), camel(matcher.group(2)), parameters, arguments,
            matcher.group(4).replace("selection.relation_query(", "query_.selectRelation(")
                .replace("child.query()", "child.runtimeQuery()"));
        consumed = matcher.end();
        continue;
      }
      String guard =
          parameters.contains("& child") ? "query_.requireCompatible(child.query_); " : "";
      fluent(
          out,
          request,
          matcher.group(1) == null ? "" : matcher.group(1),
          camel(matcher.group(2)),
          parameters,
          arguments,
          guard
              + "query_.mutate_selection([&](SelectQuery& selection) { "
              + matcher.group(4)
              + " });");
      consumed = matcher.end();
    }
    if (!source.substring(consumed).isBlank()) {
      throw new IllegalStateException("Unadapted C++ query method tail");
    }
  }

  private void fieldAdapter(StringBuilder out, String request, String method,
      String parameters, String arguments, String body) {
    line(out, request + "& " + method + "(" + parameters + ") { " + body + " return *this; }");
  }

  private void relationSelectionInputs(StringBuilder out, String request, String relation, String identity) {
    String method = camel("select_" + relation + "_with");
    fluent(out, request,
        "template <class ChildRequest> requires requires (const ChildRequest& child) { child.runtimeQuery().selection(); } ",
        method, "const ChildRequest& child", "child",
        "query_.selectRelation(" + quote(identity) + ", child.runtimeQuery());");
    for (String type : List.of("SelectQuery", "request::QuerySelection")) {
      fluent(out, request, "", method, "const " + type + "& child", "child",
          "query_.selectRelation(" + quote(identity) + ", child);");
    }
  }

  // Diagnostic suggestions use canonical paths. Prefixes make keyword names legal C++ APIs.
  private void relationSelectionAliases(StringBuilder out, String request, String member,
      String identity, boolean forward) {
    String original = camel("select_" + member), alias = camel("select_" + identity);
    if (original.equals(alias)) {
      return;
    }
    fluent(out, request, "", alias, "", "", original + "();");
    fluent(out, request,
        "template <class ChildRequest> requires requires (" + request
            + "& self, const ChildRequest& child) { self." + original + "With(child); } ",
        alias + "With", "const ChildRequest& child", "child", original + "With(child);");
    if (forward) {
      fluent(out, request, "", camel("unselect_" + identity), "", "",
          camel("unselect_" + member) + "();");
    }
  }

  private void analysisSelectionInputs(StringBuilder out, String request, String method,
      String prefix, String suffix, String body) {
    for (String input : List.of("ChildRequest", "SelectQuery", "request::QuerySelection")) {
      String template = input.equals("ChildRequest")
          ? "template <class ChildRequest> requires requires (const ChildRequest& child) { child.runtimeQuery().selection(); } " : "";
      String parameters = prefix + "const " + input + "& child" + suffix;
      String delegate = body.replace("CHILD_INPUT", input.equals("ChildRequest") ? "child.runtimeQuery()" : "child");
      fluent(out, request, template, camel(method), parameters, cppArguments(parameters), delegate);
    }
  }

  private void objectAnalysisInputs(StringBuilder out, String request, FieldDescriptor field) {
    String member = RustFieldDescriptorNaming.rustMemberName(field);
    String relation = quote(member), storage = quote(canonical(field));
    String target = typeName(((ObjectType) field.getFieldType()).getRefer());
    String descriptor = target + "::entity_descriptor(memory_resource())";
    for (boolean negative : List.of(false, true)) {
      analysisSelectionInputs(out, request, (negative ? "without_" : "with_") + member + "_matching", "", "",
          "query_.filterRelation(" + storage + ", \"id\", " + descriptor + ", CHILD_INPUT, " + negative + ", " + relation + ");");
    }
    analysisSelectionInputs(out, request, "roll_up_to_" + member + "_with", "", "",
        "query_.filterRelation(" + storage + ", \"id\", " + descriptor + ", CHILD_INPUT, false, " + relation + "); "
            + "query_.groupByObject(" + relation + ", " + storage + ", CHILD_INPUT);");
    analysisSelectionInputs(out, request, "facet_by_" + member + "_as", "std::string_view facet_name, ", "",
        "query_.facetBy(" + relation + ", facet_name, CHILD_INPUT);");
    analysisSelectionInputs(out, request, "facet_by_" + member + "_as_with_options", "std::string_view facet_name, ", ", bool include_all_facets",
        "query_.facetBy(" + relation + ", facet_name, CHILD_INPUT, include_all_facets);");
    for (String method : List.of("group_by_" + member + "_with", "group_by_" + member + "_with_details_from")) {
      analysisSelectionInputs(out, request, method, "", "",
          "query_.groupByObject(" + relation + ", " + storage + ", CHILD_INPUT);");
    }
  }

  private void reverseMatchingInputs(StringBuilder out, String request, ReverseRelation relation) {
    String member = RustReverseRelationNaming.rustMemberName(relation);
    String foreign = quote(canonical(relation.getProperty()));
    String descriptor = typeName(relation.getChild()) + "::entity_descriptor(memory_resource())";
    for (boolean negative : List.of(false, true)) {
      analysisSelectionInputs(out, request, (negative ? "without_" : "with_") + member + "_matching", "", "",
          "query_.filterRelation(\"id\", " + foreign + ", " + descriptor + ", CHILD_INPUT, " + negative + ", " + quote(member) + ");");
    }
  }

  private void reverseAnalysisInputs(StringBuilder out, String request, ReverseRelation relation) {
    String plural = RustReverseRelationNaming.rustMemberNames(relation);
    String member = quote(RustReverseRelationNaming.rustMemberName(relation));
    analysisSelectionInputs(out, request, "count_" + plural + "_with", "std::string_view alias, ", "",
        "query_.aggregateRelation(" + member + ", alias, CHILD_INPUT, true);");
    analysisSelectionInputs(out, request, "stats_from_" + plural, "", "",
        "query_.aggregateRelation(" + member + ", \"refinements\", CHILD_INPUT, false);");
    analysisSelectionInputs(out, request, "stats_from_" + plural + "_as", "std::string_view alias, ", "",
        "query_.aggregateRelation(" + member + ", alias, CHILD_INPUT, false);");
    analysisSelectionInputs(out, request, "group_by_" + plural + "_with_details", "", "",
        "query_.aggregateRelation(" + member + ", \"refinements\", CHILD_INPUT, false);");
    for (RustRelationAggregateMethod method : RustReverseRelationNaming.rustFieldAggregateMethods(relation)) {
      String function = switch (method.getQueryMethodName()) {
        case "sum" -> "Sum"; case "avg" -> "Avg"; case "min" -> "Min"; case "max" -> "Max";
        case "stddev" -> "Stddev"; case "stddev_pop" -> "StddevPop";
        case "var_samp" -> "VarSamp"; case "var_pop" -> "VarPop";
        default -> throw new IllegalArgumentException("Unsupported source relationship statistic " + method.getQueryMethodName());
      };
      analysisSelectionInputs(out, request, method.getAliasName(), "std::string_view alias, ", "",
          "query_.aggregateRelationField(" + member + ", alias, CHILD_INPUT, " + quote(method.getFieldStorageName())
              + ", " + quote(method.getQueryAlias()) + ", AggregateFunction::" + function + ");");
    }
  }

  private void analysisAdapter(StringBuilder out, String request, String target, String method,
      String parameters, String body) {
    line(out, "template <bool P, Entity ChildResult> requires (!P) " + request + "& " + method
        + "(" + parameters + "const " + target + "Request<P, ChildResult>& child) { " + body + " return *this; }");
  }

  private void objectAnalysisMethods(StringBuilder out, String request, FieldDescriptor field) {
    String member = RustFieldDescriptorNaming.rustMemberName(field);
    String target = typeName(((ObjectType) field.getFieldType()).getRefer());
    String relation = quote(member), storage = quote(canonical(field));
    String child = "query_.template relatedQuery<" + target + ">().unlimited()";
    for (boolean negative : List.of(false, true)) {
      analysisAdapter(out, request, target, (negative ? "without_" : "with_") + member + "_matching", "",
          "query_.filterRelation(" + storage + ", \"id\", child.query_, " + negative + ", " + relation + ");");
      fieldAdapter(out, request, "have_" + (negative ? "no_" : "") + member, "", "",
          "selection.and_filter(Expr::" + (negative ? "is_null" : "is_not_null") + "(memory_resource(), " + storage + "));");
    }
    analysisAdapter(out, request, target, "facet_by_" + member + "_as", "std::string_view facet_name, ",
        "query_.facetBy(" + relation + ", facet_name, child.query_);");
    line(out, "template <bool P, Entity ChildResult> requires (!P) " + request + "& facet_by_" + member
        + "_as_with_options(std::string_view facet_name, const " + target
        + "Request<P, ChildResult>& child, bool include_all_facets) { query_.facetBy(" + relation
        + ", facet_name, child.query_, include_all_facets); return *this; }");
    for (String method : List.of("group_by_" + member + "_with", "group_by_" + member + "_with_details_from")) {
      analysisAdapter(out, request, target, method, "", "query_.groupByObject(" + relation + ", " + storage + ", child.query_);");
    }
    fieldAdapter(out, request, "group_by_" + member + "_with_details", "", "",
        "query_.groupByObject(" + relation + ", " + storage + ", " + child + ");");
    fieldAdapter(out, request, "roll_up_to_" + member, "", "",
        "auto child = " + child + "; query_.filterRelation(" + storage + ", \"id\", child, false, " + relation + "); query_.groupByObject(" + relation + ", " + storage + ", child);");
    analysisAdapter(out, request, target, "roll_up_to_" + member + "_with", "",
        "query_.filterRelation(" + storage + ", \"id\", child.query_, false, " + relation + "); query_.groupByObject(" + relation + ", " + storage + ", child.query_);");
  }

  private void reverseAnalysisMethods(StringBuilder out, String request, ReverseRelation relation, boolean many) {
    String member = RustReverseRelationNaming.rustMemberName(relation);
    String plural = RustReverseRelationNaming.rustMemberNames(relation);
    String target = typeName(relation.getChild());
    String relationName = quote(member), foreign = quote(canonical(relation.getProperty()));
    String minimal = "query_.template relatedQuery<" + target + ">(true)";
    String child = "query_.template relatedQuery<" + target + ">().unlimited()";
    for (boolean negative : List.of(false, true)) {
      fieldAdapter(out, request, "have_" + (negative ? "no_" : "") + plural, "", "",
          "query_.filterRelation(\"id\", " + foreign + ", " + minimal + ", " + negative + ", " + relationName + ");");
      analysisAdapter(out, request, target, (negative ? "without_" : "with_") + member + "_matching", "",
          "query_.filterRelation(\"id\", " + foreign + ", child.query_, " + negative + ", " + relationName + ");");
    }
    if (!many) { return; }
    RustRelationAggregateMethod count = RustReverseRelationNaming.rustCountAggregateMethod(relation);
    fieldAdapter(out, request, count.getName(), "", "",
        "query_.aggregateRelation(" + relationName + ", " + quote(count.getDefaultAlias()) + ", " + child + ", true);");
    fieldAdapter(out, request, count.getAliasName(), "std::string_view alias", "alias",
        "query_.aggregateRelation(" + relationName + ", alias, " + child + ", true);");
    analysisAdapter(out, request, target, "count_" + plural + "_with", "std::string_view alias, ",
        "query_.aggregateRelation(" + relationName + ", alias, child.query_, true);");
    analysisAdapter(out, request, target, "stats_from_" + plural, "",
        "query_.aggregateRelation(" + relationName + ", \"refinements\", child.query_, false);");
    analysisAdapter(out, request, target, "stats_from_" + plural + "_as", "std::string_view alias, ",
        "query_.aggregateRelation(" + relationName + ", alias, child.query_, false);");
    analysisAdapter(out, request, target, "group_by_" + plural + "_with_details", "",
        "query_.aggregateRelation(" + relationName + ", \"refinements\", child.query_, false);");
    for (RustRelationAggregateMethod method : RustReverseRelationNaming.rustFieldAggregateMethods(relation)) {
      String function = switch (method.getQueryMethodName()) {
        case "sum" -> "Sum"; case "avg" -> "Avg"; case "min" -> "Min"; case "max" -> "Max";
        case "stddev" -> "Stddev"; case "stddev_pop" -> "StddevPop";
        case "var_samp" -> "VarSamp"; case "var_pop" -> "VarPop";
        default -> throw new IllegalArgumentException("Unsupported source relationship aggregate " + method.getQueryMethodName());
      };
      String operands = quote(method.getFieldStorageName()) + ", " + quote(method.getQueryAlias()) + ", AggregateFunction::" + function;
      fieldAdapter(out, request, method.getName(), "", "",
          "query_.aggregateRelationField(" + relationName + ", " + quote(method.getDefaultAlias()) + ", " + child + ", " + operands + ");");
      analysisAdapter(out, request, target, method.getAliasName(), "std::string_view alias, ",
          "query_.aggregateRelationField(" + relationName + ", alias, child.query_, " + operands + ");");
    }
  }

  private void queryFieldCriteria(StringBuilder out, String request, FieldDescriptor fd) {
    if (fd.isVersion() || fd.isBoolean() || fd.isObjectProperty() || CppBusinessIdMetadata.isBusinessId(fd)) {
      return;
    }
    String prefix = camel(identifier(FieldDescriptorNaming.attributePredicatePrefixExpr(fd)));
    String field = quote(canonical(fd));
    String rangeTemplate = "template <std::ranges::input_range Inputs> requires std::constructible_from<Value, Memory, std::ranges::range_reference_t<Inputs>> ";
    String scalarTemplate = "template <class Input> requires std::constructible_from<Value, Memory, const Input&> ";
    if (baseType(fd).equals("String") && !fd.getBooleanAttribute("isText") && !fd.getBooleanAttribute("isPassword")) {
      String soundName = camel(identifier(FieldDescriptorNaming.attributePredicatePrefixExpr(fd)
          + "Sound" + FieldDescriptorNaming.attributePredicateSuffixExpr(fd) + "Like"));
      fluent(out, request, scalarTemplate, soundName, "const Input& value", "value",
          "query_.andFilter(Expr::sound_like(memory_resource(), " + field + ", value));");
    }
    for (String[] comparison : List.of(new String[]{"Is", "eq"}, new String[]{"IsNot", "ne"},
        new String[]{"GreaterThan", "gt"}, new String[]{"GreaterThanOrEqualTo", "gte"},
        new String[]{"LessThan", "lt"}, new String[]{"LessThanOrEqualTo", "lte"})) {
      if (fd.isId() && !comparison[0].equals("Is") && !comparison[0].equals("IsNot")) { continue; }
      fluent(out, request, scalarTemplate, prefix + comparison[0], "const Input& value", "value",
          "query_.andFilter(Expr::" + comparison[1] + "(memory_resource(), " + field + ", value));");
    }
    if (!fd.isId()) {
      String betweenTemplate = "template <class Lower, class Upper> requires std::constructible_from<Value, Memory, const Lower&> && std::constructible_from<Value, Memory, const Upper&> ";
      fluent(out, request, betweenTemplate, prefix + "Between", "const Lower& lower, const Upper& upper", "lower, upper",
          "query_.andFilter(Expr::between(memory_resource(), " + field + ", lower, upper));");
    }
    for (String suffix : List.of("In", "NotIn")) {
      fluent(out, request, rangeTemplate, prefix + suffix,
          "Inputs&& inputs", "std::forward<Inputs>(inputs)",
          "query_.filterField(" + field + ", request::FieldOperator::" + suffix
              + ", std::forward<Inputs>(inputs));");
    }
    fluent(out, request, rangeTemplate, prefix,
        "request::FieldOperator op, Inputs&& inputs", "op, std::forward<Inputs>(inputs)",
        "query_.filterField(" + field + ", op, std::forward<Inputs>(inputs));");
    line(out, rangeTemplate + "Ref<Expr> " + camel("create_" + fieldName(fd) + "_criteria")
        + "(request::FieldOperator op, Inputs&& inputs) const { return query_.createFieldCriteria("
        + field + ", op, std::forward<Inputs>(inputs)); }");
    if (!fd.isId()) {
      String valueTemplate = "template <class T> requires std::constructible_from<Value, Memory, const T&> ";
      fluent(out, request, valueTemplate, prefix + "BetweenRange",
          "const request::DateRange<T>& range", "range",
          "query_.andFilter(Expr::between(memory_resource(), " + field + ", range.start, range.end));");
      for (String suffix : List.of("Before", "After")) {
        fluent(out, request, valueTemplate, prefix + suffix, "const T& value", "value",
            "query_.andFilter(Expr::" + (suffix.equals("Before") ? "lt" : "gt")
            + "(memory_resource(), " + field + ", value));");
      }
    }
  }

  private void queryField(StringBuilder out, String request, FieldDescriptor fd) {
    String member = fieldName(fd), canonical = quote(canonical(fd));
    String sourceMember = RustFieldDescriptorNaming.rustStorageMemberName(fd);
    String prefix = identifier(FieldDescriptorNaming.attributePredicatePrefixExpr(fd));
    for (Candidate candidate : candidates(fd)) {
      for (boolean negative : List.of(false, true)) {
        String method = prefix + (negative ? "_is_not_" : "_is_")
            + candidate.getRustCandidateMethodValue();
        line(out, request + "& " + method
            + "() { selection.and_filter(Expr::" + (negative ? "ne" : "eq")
            + "(memory_resource(), " + canonical + ", "
            + candidateLiteral(fd, candidate) + ")); return *this; }");
      }
    }
    line(
        out,
        request
            + "& select_"
            + member
            + "() { selection.project("
            + canonical
            + "); return *this; }");
    if (!fd.isId() && !fd.isVersion()) {
      fieldAdapter(out, request, camel("project_" + member), "", "", "query_.select(" + canonical + ");");
      fieldAdapter(out, request, camel("select_" + member + "_raw"), "std::string_view sql", "sql", "query_.selectRaw(" + canonical + ", sql);");
      fieldAdapter(out, request, camel("select_" + member + "_unsafe_raw"), "request::UnsafeRawSqlSegment sql", "std::move(sql)", "query_.selectUnsafeRaw(" + canonical + ", std::move(sql));");
      if (!fd.isObjectProperty()) {
        fieldAdapter(out, request, camel("unselect_" + member), "", "", "query_.unselect(" + canonical + ");");
      }
      if (fd.isObjectProperty()) {
        fieldAdapter(out, request, camel("unselect_" + relationName(fd)), "", "", "query_.unselectRelation(" + canonical + ", " + quote(relationIdentity(fd)) + ");");
      }
      if (sourceNumericField(fd)) {
        fieldAdapter(out, request, camel("select_" + member + "_with_function"), "AggregateFunction function", "function", "query_.selectWithFunction(" + canonical + ", " + canonical + ", function);");
        fieldAdapter(out, request, camel("select_" + member + "_as_with_function"), "std::string_view alias, AggregateFunction function", "alias, function", "query_.selectWithFunction(" + canonical + ", alias, function);");
      }
    }
    for (String direction : List.of("asc", "desc")) {
      line(
          out,
          request
              + "& order_by_"
              + member
              + "_"
              + direction
              + "() { selection.order_"
              + direction
              + "("
              + canonical
              + "); return *this; }");
    }
    for (String direction : List.of("asc", "desc")) {
      line(out, request + "& order_by_" + member + "_" + direction + "_using_gbk() { selection.order_gbk_" + direction + "(" + canonical + "); return *this; }");
    }
    if (fd.isBoolean()) {
      line(
          out,
          request
              + "& "
              + identifier(FieldDescriptorNaming.snakeBooleanPredicateExpr(fd))
              + "() { selection.and_filter(Expr::eq(memory_resource(), "
              + canonical
              + ", true)); return *this; }");
      line(
          out,
          request
              + "& "
              + identifier(FieldDescriptorNaming.snakeBooleanNegativePredicateExpr(fd))
              + "() { selection.and_filter(Expr::eq(memory_resource(), "
              + canonical
              + ", false)); return *this; }");
    }
    for (String[] pair :
        List.of(
            new String[] {"is", "eq"},
            new String[] {"is_not", "ne"},
            new String[] {"greater_than", "gt"},
            new String[] {"greater_than_or_equal_to", "gte"},
            new String[] {"less_than", "lt"},
            new String[] {"less_than_or_equal_to", "lte"})) {
      line(
          out,
          request
              + "& "
              + prefix
              + "_"
              + pair[0]
              + "("
              + predicateType(fd)
              + " value) { selection.and_filter(Expr::"
              + pair[1]
              + "(memory_resource(), "
              + canonical
              + ", generated_detail::encode(memory_resource(), value))); return *this; }");
    }
    line(
        out,
        request
            + "& "
            + prefix
            + "_between("
            + predicateType(fd)
            + " lower, "
            + predicateType(fd)
            + " upper) { selection.and_filter(Expr::between(memory_resource(), "
            + canonical
            + ", generated_detail::encode(memory_resource(), lower),"
            + " generated_detail::encode(memory_resource(), upper))); return *this; }");
    for (String suffix : List.of("in", "not_in")) {
      line(
          out,
          request
              + "& "
              + prefix
              + "_"
              + suffix
              + "(std::span<const "
              + (CppBusinessIdMetadata.isBusinessId(fd) ? applicationType(fd) : baseType(fd))
              + "> inputs) { auto r = memory_resource(); Vector<Value> values(r); for (const auto&"
              + " value : inputs) { values.emplace_back(generated_detail::encode(r, value)); }"
              + " selection.and_filter(Expr::in_list(r, "
              + canonical
              + ", values, "
              + suffix.equals("not_in")
              + ")); return *this; }");
    }
    String aggregateMember = fd.isObjectProperty() ? relationName(fd) : member;
    String sourceCountMember = fd.isObjectProperty()
        ? RustFieldDescriptorNaming.rustMemberName(fd) : sourceMember;
    fieldAdapter(out, request, camel("group_by_" + aggregateMember), "", "",
        "query_.groupBy(" + canonical + ");");
    fieldAdapter(out, request, camel("group_by_" + aggregateMember + "_as"), "std::string_view alias", "alias",
        "query_.groupBy(" + canonical + "); query_.selectAs(" + canonical + ", alias);");
    fieldAdapter(out, request, camel("group_by_" + aggregateMember + "_with_function"),
        "std::string_view alias, AggregateFunction function", "alias, function",
        "query_.groupBy(" + canonical + "); query_.aggregateWithFunction(" + canonical + ", alias, function);");
    fieldAdapter(out, request, camel("count_" + aggregateMember), "", "",
        "query_.aggregateCountField(" + canonical + ", " + quote(sourceCountMember + "_count") + ");");
    fieldAdapter(out, request, camel("count_" + aggregateMember + "_as"), "std::string_view alias", "alias",
        "query_.aggregateCountField(" + canonical + ", alias);");
    if (!fd.isObjectProperty()) {
      for (String method : List.of("sum", "avg", "min", "max")) {
        fieldAdapter(out, request, camel(method + "_" + member), "", "",
            "query_." + camel("aggregate_" + method) + "(" + canonical + ", " + quote(method + "_" + sourceMember) + ");");
        fieldAdapter(out, request, camel(method + "_" + member + "_as"), "std::string_view alias", "alias",
            "query_." + camel("aggregate_" + method) + "(" + canonical + ", alias);");
      }
      if (sourceNumericField(fd)) {
        for (String[] method : List.of(
            new String[]{"standard_deviation", "aggregateStddev", "stdDev"},
            new String[]{"square_root_of_population_standard_deviation", "aggregateStddevPop", "stdDevPop"},
            new String[]{"sample_variance", "aggregateVarSamp", "varSamp"},
            new String[]{"sample_population_variance", "aggregateVarPop", "varPop"})) {
          fieldAdapter(out, request, camel(method[0] + "_" + member), "", "",
              "query_." + method[1] + "(" + canonical + ", " + quote(method[2] + "_" + sourceMember) + ");");
          fieldAdapter(out, request, camel(method[0] + "_" + member + "_as"), "std::string_view alias", "alias",
              "query_." + method[1] + "(" + canonical + ", alias);");
        }
      }
    }
    if (baseType(fd).equals("String")) {
      line(
          out,
          request
              + "& "
              + identifier(FieldDescriptorNaming.stringContainsPredicateExpr(fd))
              + "(std::string_view value) { selection.and_filter(Expr::contain(memory_resource(), "
              + canonical
              + ", value)); return *this; }");
      line(
          out,
          request
              + "& "
              + identifier(FieldDescriptorNaming.StringStartsWithPredicateExpr(fd))
              + "(std::string_view value) {"
              + " selection.and_filter(Expr::begin_with(memory_resource(), "
              + canonical
              + ", value)); return *this; }");
      line(
          out,
          request
              + "& "
              + identifier(FieldDescriptorNaming.StringEndsWithPredicateExpr(fd))
              + "(std::string_view value) { selection.and_filter(Expr::end_with(memory_resource(), "
              + canonical
              + ", value)); return *this; }");
    }
    if (baseType(fd).equals("String") && !CppBusinessIdMetadata.isBusinessId(fd)
        && !fd.getBooleanAttribute("isText") && !fd.getBooleanAttribute("isPassword")) {
      for (String[] method : List.of(
          new String[]{"NotContain", "not_contain", ""},
          new String[]{"NotStart", "not_begin_with", "With"},
          new String[]{"NotEnd", "not_end_with", "With"},
          new String[]{"Sound", "sound_like", "Like"})) {
        String methodName = identifier(FieldDescriptorNaming.attributePredicatePrefixExpr(fd)
            + method[0] + FieldDescriptorNaming.attributePredicateSuffixExpr(fd) + method[2]);
        line(out, request + "& " + methodName + "(std::string_view value) { selection.and_filter(Expr::"
            + method[1] + "(memory_resource(), " + canonical + ", value)); return *this; }");
      }
    }
    Set<String> candidateNames = new HashSet<>();
    for (Candidate candidate : candidates(fd)) {
      candidateNames.add(camel(prefix + "_is_" + candidate.getRustCandidateMethodValue()));
      candidateNames.add(camel(prefix + "_is_not_" + candidate.getRustCandidateMethodValue()));
    }
    // Source Unknown/Known denote SQL NULL availability. Keep established C++
    // Null/NotNull aliases only when a real candidate does not occupy that name.
    for (String[] method : List.of(new String[]{"is_unknown", "is_null"},
        new String[]{"is_known", "is_not_null"}, new String[]{"is_null", "is_null"},
        new String[]{"is_not_null", "is_not_null"})) {
      if (!candidateNames.contains(camel(prefix + "_" + method[0]))) {
        line(out, request + "& " + prefix + "_" + method[0]
            + "() { selection.and_filter(Expr::" + method[1] + "(memory_resource(), "
            + canonical + ")); return *this; }");
      }
    }
  }

  private String expressions(String ns, List<ObjectDescriptor> entities) {
    StringBuilder out = new StringBuilder(header(ns, "models.hpp"));
    for (ObjectDescriptor od : entities) {
      line(out, "class " + typeName(od) + "Expression; class " + typeName(od) + "ListExpression;");
    }
    for (ObjectDescriptor od : entities) {
      String name = typeName(od), expression = name + "Expression";
      line(
          out,
          "class "
              + expression
              + " : public RuntimeExpression<EntityBorrow<"
              + name
              + ">> { public: using Base = RuntimeExpression<EntityBorrow<"
              + name
              + ">>; explicit "
              + expression
              + "(Base value) : Base(value) {}");
      for (FieldDescriptor fd : fields(od)) {
        String member = camel(fieldName(fd)),
            type = applicationType(fd),
            path = quote(canonical(fd));
        line(
            out,
            "RuntimeExpression<"
                + type
                + "> "
                + camel("get_" + fieldName(fd))
                + "() const { return this->andThen("
                + path
                + ", [](EntityBorrow<"
                + name
                + "> source) { return RuntimeExpression<"
                + type
                + ">::from_result(source.get()."
                + camel("eval_" + fieldName(fd))
                + "()); }); }");
        if (fd.isConstantObjectField()) {
          for (Candidate candidate : candidates(fd)) {
            String method = camel(relationName(fd) + "_is_" + candidate.getRustCandidateMethodValue());
            line(out, "RuntimeExpression<bool> " + method
                + "() const { return this->andThen(" + path + ", [](EntityBorrow<" + name
                + "> source) { auto r = source.memory_resource(); if (!source.get().is_loaded("
                + path + ")) { return RuntimeExpression<bool>::not_loaded(r, " + path + ", "
                + path + "); } return RuntimeExpression<bool>::value(r, source.get()."
                + method + "()); }); }");
          }
        }
      }
      for (FieldDescriptor fd :
          fields(od).stream().filter(FieldDescriptor::isObjectProperty).toList()) {
        expressionRelationDeclaration(out,
            typeName(((ObjectType) fd.getFieldType()).getRefer()) + "Expression",
            relationName(fd), relationIdentity(fd));
      }
      for (ReverseRelation rel : od.getReverseRelations()) {
        expressionRelationDeclaration(out,
            typeName(rel.getChild())
                + (ReverseRelationNaming.oneToOne(rel) ? "Expression" : "ListExpression"),
            relationName(rel), relationIdentity(rel));
      }
      line(out, "};");
      line(
          out,
          "class "
              + name
              + "ListExpression : public RuntimeExpression<EntityListBorrow<"
              + name
              + ">> { public: using Base = RuntimeExpression<EntityListBorrow<"
              + name
              + ">>; explicit "
              + name
              + "ListExpression(Base value) : Base(value) {}");
      line(
          out,
          expression
              + " get(std::size_t index) const { auto next = this->andThen(\"get\","
              + " [index](EntityListBorrow<"
              + name
              + "> source) { auto r = source.memory_resource(); auto* value ="
              + " source.get().get(index); using Output = RuntimeExpression<EntityBorrow<"
              + name
              + ">>; return value ? entity_expression(*value) : Output::null(r); }); return "
              + expression
              + "(next); }");
      line(
          out,
          expression
              + " first() const { return get(0); } RuntimeExpression<std::size_t> size() const {"
              + " return this->map([](EntityListBorrow<"
              + name
              + "> source) { return source.get().len(); }); } }; ");
    }
    for (ObjectDescriptor od : entities) {
      for (FieldDescriptor fd :
          fields(od).stream().filter(FieldDescriptor::isObjectProperty).toList()) {
        expressionRelation(
            out,
            typeName(od),
            relationName(fd),
            relationIdentity(fd),
            typeName(((ObjectType) fd.getFieldType()).getRefer()),
            false);
      }
      for (ReverseRelation rel : od.getReverseRelations()) {
        expressionRelation(
            out,
            typeName(od),
            relationName(rel),
            relationIdentity(rel),
            typeName(rel.getChild()),
            !ReverseRelationNaming.oneToOne(rel));
      }
    }
    line(out, "struct E {");
    for (ObjectDescriptor od : entities) {
      String name = typeName(od), method = camel(identifier(od.getName()));
      line(
          out,
          "static "
              + name
              + "Expression "
              + method
              + "(const "
              + name
              + "& value) { return "
              + name
              + "Expression(entity_expression(value)); }");
      line(
          out,
          "static "
              + name
              + "Expression "
              + method
              + "("
              + name
              + "&&) = delete; static "
              + name
              + "Expression "
              + method
              + "(const "
              + name
              + "&&) = delete;");
    }
    line(out, "};\n}");
    return out.toString();
  }

  private void expressionRelationDeclaration(StringBuilder out, String expression,
      String member, String identity) {
    line(out, expression + " " + camel("get_" + member) + "() const;");
    if (!camel("get_" + member).equals(camel("get_" + identity))) {
      line(out, expression + " " + camel("get_" + identity) + "() const;");
    }
  }

  private void expressionRelation(
      StringBuilder out, String name, String member, String identity, String target, boolean many) {
    String expression = target + (many ? "ListExpression" : "Expression");
    String payload = (many ? "EntityListBorrow<" : "EntityBorrow<") + target + ">";
    line(
        out,
        "inline "
            + expression
            + " "
            + name
            + "Expression::"
            + camel("get_" + member)
            + "() const { auto next = this->andThen("
            + quote(identity)
            + ", [](EntityBorrow<"
            + name
            + "> source) { return RuntimeExpression<"
            + payload
            + ">::from_result(source.get()."
            + camel("eval_" + member)
            + "()); }); return "
            + expression
            + "(next); }");
    if (!camel("get_" + member).equals(camel("get_" + identity))) {
      line(out, "inline " + expression + " " + name + "Expression::"
          + camel("get_" + identity) + "() const { return " + camel("get_" + member) + "(); }");
    }
  }

  private String checkers(String ns, List<ObjectDescriptor> entities) {
    StringBuilder out = new StringBuilder(header(ns, "models.hpp"));
    for (ObjectDescriptor od : entities) {
      String name = typeName(od);
      String logic = name + "CheckerLogic", noop = "Noop" + name + "Checker";
      String callback = "checkAndFix" + name;
      line(
          out,
          "class "
              + logic
              + " : public GeneratedCheckerLogic { public: using"
              + " GeneratedCheckerLogic::GeneratedCheckerLogic; virtual void "
              + callback
              + "(const UserContext&, "
              + name
              + "&, CheckObjectStatus, const ObjectLocation&, CheckResults&) const {} }; ");
      line(
          out,
          "class "
              + noop
              + " final : public "
              + logic
              + " { public: using "
              + logic
              + "::"
              + logic
              + "; }; ");
      line(
          out,
          "class "
              + name
              + "Checker final : public TypedChecker<"
              + name
              + "> { public: using allocator_type = Allocator; ");
      line(
          out,
          name
              + "Checker(std::allocator_arg_t, Allocator a) : "
              + name
              + "Checker(std::allocator_arg, a, detail::resource_arena(a.resource()).make<"
              + noop
              + ">()) {} ");
      line(
          out,
          "template<class L> requires std::derived_from<L, "
              + logic
              + "> "
              + name
              + "Checker(std::allocator_arg_t, Allocator a, const L& value) :"
              + " logic_(GeneratedFieldChecks::bind_logic<"
              + logic
              + ">(a, value)) {} ");
      line(
          out,
          name
              + "Checker(std::allocator_arg_t, Allocator a, const "
              + name
              + "Checker& other) : logic_(std::allocator_arg, a, other.logic_) {} ");
      line(out, "Memory memory_resource() const { return logic_.memory_resource(); }");
      line(
          out,
          "void check_and_fix_typed(const UserContext& user_context, "
              + name
              + "& entity, CheckObjectStatus status, const ObjectLocation& location, CheckResults&"
              + " results) const override { detail::CheckerCallScope"
              + " active(detail::checker_call_arena(user_context)); const auto& logic ="
              + " logic_.get();");
      for (FieldDescriptor field : CppFieldLayoutMetadata.fields(od)) {
        String path = quote(FieldDescriptorNaming.canonicalPropertyName(field));
        String setter = camel("update_" + fieldName(field));
        if (CppBusinessIdMetadata.isBusinessId(field)) {
          ObjectDescriptor root = CppBusinessIdMetadata.root(od);
          String idType = applicationType(field);
          line(
              out,
              "GeneratedFieldChecks::business_id(user_context, status, "
                  + idType
                  + "::definition(user_context.memory_resource()), "
                  + quote(root == null ? name : typeName(root))
                  + ", "
                  + name
                  + "::ENTITY_NAME, entity."
                  + fieldName(field)
                  + "_, entity."
                  + camel(fieldName(field))
                  + "().asStr().empty(), [&](std::string_view value) { entity."
                  + setter
                  + "(GeneratedBusinessIdAccess::from_canonical<"
                  + idType
                  + ">(user_context.memory_resource(), value)); }, location, results);");
        }
        if (sourceTemplateFlag(field, "contextRoot")) {
          String target = typeName(((ObjectType) field.getFieldType()).getRefer());
          line(
              out,
              "GeneratedFieldChecks::context_root(user_context, status, "
                  + name
                  + "::ENTITY_NAME, "
                  + path
                  + ", "
                  + quote(target)
                  + ", entity."
                  + camel(fieldName(field))
                  + "(), [&](std::uint64_t id) { entity."
                  + setter
                  + "(id); }, location, results);");
        }
        if (sourceTemplateFlag(field, "createFunction")) {
          emitClockFix(out, field, name, path, setter, false);
        }
        if (sourceTemplateFlag(field, "updateFunction")) {
          emitClockFix(out, field, name, path, setter, true);
        }
      }
      for (FieldDescriptor field : CppFieldLayoutMetadata.fields(od)) {
        line(
            out,
            "GeneratedFieldChecks::require_loaded(entity.is_loaded("
                + quote(canonical(field))
                + "), status, "
                + quote(FieldDescriptorNaming.canonicalPropertyName(field))
                + ", location, results);");
        if (CppBusinessIdMetadata.isBusinessId(field)) {
          line(
              out,
              "{ auto dirty = entity.dirty_fields(); GeneratedFieldChecks::immutable_business_id("
                  + "dirty && dirty->contains("
                  + quote(canonical(field))
                  + "), status, "
                  + quote(FieldDescriptorNaming.canonicalPropertyName(field))
                  + ", location, results); }");
        }
      }
      line(out, "logic." + callback + "(user_context, entity, status, location, results); }");
      line(out, "private: ResourceBorrow<const " + logic + "> logic_; }; ");
      line(
          out,
          "class "
              + name
              + "Behavior : public EntityDataServiceBehavior { public: using allocator_type ="
              + " Allocator; "
              + name
              + "Behavior(std::allocator_arg_t, Allocator) {} }; ");
    }
    line(out, "}");
    return out.toString();
  }

  // SKYNETObjectAdaptor returns recognized Boolean tokens as booleans and every
  // other nonempty attribute as a String; StringTemplate treats that as true.
  private static boolean sourceTemplateFlag(FieldDescriptor field, String attribute) {
    String value = field.getAttributeValue(attribute);
    if (value == null || value.isEmpty()) { return false; }
    return !Set.of("false", "off", "no").contains(value.toLowerCase(Locale.ROOT));
  }

  // The source adaptor resolves nonempty attributes before JavaBean methods.
  // In particular float inherits isNumber=true despite FieldDescriptor.isNumber().
  private static boolean sourceNumericField(FieldDescriptor field) {
    String value = field.getAttributeValue("isNumber");
    return value == null || value.isEmpty() ? field.isNumber() : sourceTemplateFlag(field, "isNumber");
  }

  private void emitClockFix(StringBuilder out, FieldDescriptor field, String name,
      String path, String setter, boolean update) {
    if (!baseType(field).equals("Timestamp") && !CppBusinessIdMetadata.isBusinessId(field)) {
      line(out, "GeneratedFieldChecks::clock_value(user_context, status, " + update + ", "
          + name + "::ENTITY_NAME, " + path + ", " + quote(canonical(field))
          + ", entity.root, entity.entity_key(), entity."
          + fieldName(field) + "_, entity.load_state);");
    } else {
      line(out, "GeneratedFieldChecks::clock(user_context, status, " + update + ", "
          + name + "::ENTITY_NAME, " + path + ", [&](Timestamp time) { entity."
          + setter + "(time); });");
    }
  }

  private String sampleData(String ns, List<ObjectDescriptor> entities) {
    StringBuilder out = new StringBuilder(header(ns, "queries.hpp"));
    List<ObjectDescriptor> ordered = entities.stream()
        .filter(od -> !od.getBooleanAttribute(Attributes.ATTRIBUTE_VIEW)
            && !od.getBooleanAttribute(Attributes.ATTRIBUTE_VALUE_OBJECT))
        .sorted(Comparator.comparingInt(ObjectDescriptor::getDepth).thenComparing(ObjectDescriptor::getName)).toList();
    line(out, "namespace generated_detail {");
    for (ObjectDescriptor od : ordered) {
      String name = typeName(od), plural = camel(identifier(PluralizationUtils.pluralize(od.getName())));
      boolean load = od.getDepth() == 0 || od.isConstant();
      // The locked 5.0.6 producer uses complete predefined fields, including ancestors.
      List<FieldDescriptor> predefined = CppFieldLayoutMetadata.fields(od);
      List<FieldDescriptor> objects = predefined.stream().filter(FieldDescriptor::isObjectProperty).toList();
      List<FieldDescriptor> required = objects.stream().filter(FieldDescriptorNaming::required).toList();
      line(out, "struct " + name + "SampleRecipe { using Model = " + name + ";");
      line(out, "static constexpr std::string_view name = " + quote(od.getName()) + ";");
      line(out, "static constexpr bool load_references = " + load + ";");
      line(out, "static constexpr bool has_reverse = " + !od.getReverseRelations().isEmpty() + ";");
      line(out, "static constexpr std::size_t object_fields = " + objects.size() + ";");
      line(out, "static constexpr std::array<std::string_view, " + required.size() + "> required_dependencies{" + required.stream()
          .map(fd -> quote(((ObjectType)fd.getFieldType()).getRefer().getName())).reduce((a,b)->a+", "+b).orElse("") + "};");
      line(out, "static auto& query(UserContext& user_context) { auto Q = user_context.queries<query_factory>(); return Q."
          + plural + "().comment(\"what: inspect existing entities before sample-data initialization\").purpose(\"why: avoid duplicate sample records\").executeForList(user_context); }");
      if (!load) {
        line(out, "static Model& create(UserContext& user_context) { auto Q = user_context.queries<query_factory>(); return Q."
            + plural + "().comment(\"what: initialize a sample entity\").purpose(\"why: populate the requested sample dataset\").newEntity(user_context); }");
        line(out, "static void fill(UserContext& user_context, Model& entity, SampleDataState& state, std::size_t index) { auto r = user_context.memory_resource(); std::pmr::unordered_set<std::uint64_t> used(r);");
        for (FieldDescriptor field : objects) {
          String target = ((ObjectType)field.getFieldType()).getRefer().getName();
          line(out, "if (auto id = state.pickUnusedId(" + quote(target) + ", index, used)) { entity."
              + camel("update_" + fieldName(field)) + "(*id); used.insert(*id); }");
        }
        for (FieldDescriptor field : predefined.stream().filter(FieldDescriptor::isSimpleProperty).toList()) {
          if (field.isId() || field.isVersion() || CppBusinessIdMetadata.isBusinessId(field)) { continue; }
          String base = baseType(field), value = null;
          String sample = Objects.toString(field.getDefaultSampleValue(), "");
          boolean number = false;
          if (field.isJsonLiteral() || field.isString()) {
            value = "GeneratedSampleValues::text(r, " + quote(sample) + ", index)";
            if (base.equals("Json")) {
              // Source sample setters receive Text; unconvertible JSON retains native storage.
              line(out, "{ auto original = " + value + "; entity.root.set(entity.entity_key(), "
                  + quote(canonical(field)) + ", Value(r, original)); auto& pool = detail::ContextArena::from_memory(r).loaded_snapshots(); entity.load_state.mark_loaded("
                  + quote(canonical(field)) + ", &pool).value(); }");
              continue;
            }
          } else if (field.getBooleanAttribute("isNumber") || field.isNumber()) {
            number = true;
            line(out, "{ auto original = GeneratedSampleValues::number(state.plan, index, " + quote(sample) + ");");
            if (base.equals("String")) {
              line(out, "GeneratedSampleValues::unconverted_value(entity, " + quote(canonical(field))
                  + ", Value(r, original)); }");
              continue;
            }
            value = base.equals("Decimal") ? "Decimal::from_i64(original)" : "static_cast<" + base + ">(original)";
          } else if (RustFieldDescriptorNaming.rustTimestamp(field)) {
            value = "GeneratedSampleValues::timestamp(state.plan, index)";
          } else if (field.isDate()) {
            value = "GeneratedSampleValues::date(state.plan, index)";
          } else if (field.isTime()) {
            value = "GeneratedSampleValues::time(r, state.plan, index)";
          } else if (RustFieldDescriptorNaming.rustBoolean(field)) {
            value = RustFieldDescriptorNaming.rustDefaultBooleanSampleValue(field);
          }
          if (value != null) {
            if (field.getBooleanAttribute("optional")) { value = storageType(field) + "(std::in_place, " + value + ")"; }
            line(out, "entity." + camel("update_" + fieldName(field)) + "(" + value + ");");
            if (number) {
              line(out, "entity.root.set(entity.entity_key(), " + quote(canonical(field)) + ", Value(r, original)); }");
            }
          }
        }
        line(out, "}");
      }
      line(out, "};");
    }
    line(out, "}\ninline SampleDataFuture& generateSampleData(UserContext& user_context, SampleDataPlan plan) {");
    List<ObjectDescriptor> steps = new ArrayList<>();
    steps.addAll(ordered.stream().filter(od->od.getDepth()==0).toList());
    steps.addAll(ordered.stream().filter(od->od.getDepth()>0 && od.isConstant()).toList());
    steps.addAll(ordered.stream().filter(od->od.getDepth()>0 && !od.isConstant()).toList());
    line(out, "const std::array<GeneratedSampleStep, " + steps.size() + "> steps{" + steps.stream()
        .map(od->"run_generated_sample_model<generated_detail::"+typeName(od)+"SampleRecipe>")
        .reduce((a,b)->a+", "+b).orElse("") + "};");
    line(out, "return run_generated_sample_data(user_context, plan, steps); }\n}");
    return out.toString();
  }

  private String runtime(String ns, List<ObjectDescriptor> entities, Domain domain) {
    if (entities.stream().anyMatch(ObjectDescriptor::isConstant) && !hasGeneratedBootstrap(entities)) {
      throw new IllegalArgumentException("Generated bootstrap requires exactly one Domain Root");
    }
    String preamble = header(ns, "checkers.hpp");
    if (hasGeneratedBootstrap(entities)) {
      preamble = preamble.replace("#include \"checkers.hpp\"", "#include \"checkers.hpp\"\n#include \"queries.hpp\"");
    }
    StringBuilder out = new StringBuilder(preamble);
    line(out, "using ServiceRuntime = UserContext;");
    line(out, "using ServiceRuntimeError = GeneratedServiceRuntimeError<SqliteDriverError>;");
    line(out, "using DataServiceConnection = Ref<SqliteConnection>;");
    line(out, "inline constexpr std::string_view DATABASE_URL_ENV = "
        + quote(RustDomainNaming.rustEnvPrefix(domain) + "_DATABASE_URL") + ";");
    line(out, "struct ServiceRuntimeConfig : GeneratedServiceRuntimeConfig {");
    line(out, "using GeneratedServiceRuntimeConfig::GeneratedServiceRuntimeConfig;");
    line(out, "std::string_view databaseUrl() const { return database_url; }");
    line(out, "static Result<ServiceRuntimeConfig, ServiceRuntimeError> fromEnv(UserContext& user_context) {");
    line(out, "auto r = user_context.memory_resource(); auto value = read_generated_runtime_config(r, DATABASE_URL_ENV);");
    line(out, "using Output = Result<ServiceRuntimeConfig, ServiceRuntimeError>; if (!value) { return Output::err(r, ServiceRuntimeError::from_preparation(r, value.error())); }");
    line(out, "return Output::ok(r, ServiceRuntimeConfig(std::allocator_arg, Allocator(r), value.value())); }");
    line(out, "};");
    line(out, "using DataServiceDialect = SqliteDialect;");
    line(out, "using DataServiceMutationExecutor = SqliteMutationExecutor;");
    line(out, "using DataServiceMutationError = MutationExecutorError;");
    line(out, "using DataServiceIdGenerator = SqliteIdSpaceGenerator;");
    if (entities.stream().flatMap(entity -> fields(entity).stream()).anyMatch(CppBusinessIdMetadata::isBusinessId)) {
      line(out, "using DataServiceBusinessIdAllocator = SqliteBusinessIdAllocator;");
    }
    line(out, "class LocalSchemaProvider final : public GeneratedLocalSchemaProvider {");
    line(out, "public: LocalSchemaProvider(std::allocator_arg_t, Allocator a) : GeneratedLocalSchemaProvider(std::allocator_arg, a, lookup) {}");
    line(out, "LocalSchemaProvider(std::allocator_arg_t, Allocator a, const LocalSchemaProvider& other) : GeneratedLocalSchemaProvider(std::allocator_arg, a, other) {}");
    line(out, "private: static std::optional<EntityDescriptor> lookup(Memory r, std::string_view name) {");
    for (ObjectDescriptor entity : entities) {
      line(out, "if (name == " + typeName(entity) + "::ENTITY_NAME) { return " + typeName(entity) + "::entity_descriptor(r); }");
    }
    line(out, "return std::nullopt; } };");
    line(out, "inline InMemoryEntityRegistry& repositoryRegistry(UserContext& user_context) { auto& registry = user_context.make<InMemoryEntityRegistry>();");
    for (ObjectDescriptor entity : entities) {
      line(out, "registry.register_entity(" + typeName(entity) + "::ENTITY_NAME);");
    }
    line(out, "return registry; }");
    line(out, "inline InMemoryEntityDataServiceBehaviorRegistry& behaviorRegistry(UserContext& user_context) { auto& registry = user_context.make<InMemoryEntityDataServiceBehaviorRegistry>();");
    for (ObjectDescriptor entity : entities) {
      String name = typeName(entity);
      line(out, "{ auto& behavior = user_context.make<" + name + "Behavior>(); registry.register_behavior(" + name + "::ENTITY_NAME, user_context, behavior); }");
    }
    line(out, "return registry; }");
    line(out, "inline InMemoryCheckerRegistry& checkerRegistry(UserContext& user_context) { auto& registry = user_context.make<InMemoryCheckerRegistry>();");
    for (ObjectDescriptor entity : entities) {
      String name = typeName(entity);
      line(out, "{ auto& checker = user_context.make<" + name + "Checker>(); auto& adapter = user_context.make<TypedEntityChecker<" + name + ", " + name + "Checker>>(user_context, checker); registry.register_checker(user_context, adapter); }");
    }
    line(out, "return registry; }");
    line(out, "inline GeneratedWireFieldMappings& generatedWireFieldMappings(UserContext& user_context) { auto& mappings = user_context.make<GeneratedWireFieldMappings>(); auto r = user_context.memory_resource();");
    for (ObjectDescriptor entity : entities) {
      line(out, "{ auto& fields = mappings.try_emplace(String(" + quote(typeName(entity)) + ", r)).first->second;");
      // runtime/index.stg deliberately uses own fields, not predefined/inherited fields.
      for (FieldDescriptor field : entity.getFields()) {
        line(out, "fields.insert_or_assign(String(" + quote(FieldDescriptorNaming.canonicalPropertyName(field))
            + ", r), String(" + quote(field.getJsonFieldName()) + ", r));");
      }
      line(out, "}");
    }
    line(out, "return mappings; }");
    line(out, "inline GeneratedWireFieldMappings& generatedWireFieldAliases(UserContext& user_context) { return user_context.make<GeneratedWireFieldMappings>(); }");
    if (hasGeneratedBootstrap(entities)) {
      bootstrap(out, entities);
    }
    line(out, "inline RuntimeModule& module(UserContext& user_context) { auto& module = user_context.make<RuntimeModule>();");
    for (ObjectDescriptor entity : entities) { line(out, "module.entity<" + typeName(entity) + ">();"); }
    if (hasGeneratedBootstrap(entities)) { line(out, "module.generated_schema_bootstrap(generated_detail::ensure_bootstrap);"); }
    line(out, "return module; }");
    for (int mode = 0; mode < 3; ++mode) {
      String method =
          mode == 0
              ? "moduleWithCheckers"
              : mode == 1 ? "moduleWithBehaviors" : "moduleWithBehaviorsAndCheckers";
      line(
          out,
          "inline RuntimeModule& "
              + method
              + "(UserContext& user_context) { auto& module = user_context.make<RuntimeModule>();");
      for (ObjectDescriptor od : entities) {
        String name = typeName(od);
        if (mode == 0) {
          line(out, "module.entity<" + name + ">();");
        } else {
          line(
              out,
              "auto& "
                  + identifier(od.getName())
                  + "_behavior = user_context.make<"
                  + name
                  + "Behavior>(); module.entity_with_behavior<"
                  + name
                  + ">(user_context, "
                  + identifier(od.getName())
                  + "_behavior);");
        }
        if (mode != 1) {
          line(
              out,
              "auto& "
                  + identifier(od.getName())
                  + "_checker = user_context.make<"
                  + name
                  + "Checker>(); auto& "
                  + identifier(od.getName())
                  + "_adapter = user_context.make<TypedEntityChecker<"
                  + name
                  + ", "
                  + name
                  + "Checker>>(user_context, "
                  + identifier(od.getName())
                  + "_checker); module.checker(user_context, "
                  + identifier(od.getName())
                  + "_adapter);");
        }
      }
      if (hasGeneratedBootstrap(entities)) {
        line(out, "module.generated_schema_bootstrap(generated_detail::ensure_bootstrap);");
      }
      line(out, "return module; }");
    }
    boolean hasBusinessIds = entities.stream().flatMap(entity -> fields(entity).stream())
        .anyMatch(CppBusinessIdMetadata::isBusinessId);
    line(out, "inline Ref<DataServiceExecutor> serviceRuntimeFromConnection(UserContext& user_context, DataServiceConnection connection) {");
    line(out, "auto& module = moduleWithBehaviorsAndCheckers(user_context); auto& schema_provider = user_context.make<LocalSchemaProvider>(); return assemble_generated_sqlite_runtime<DataServiceExecutor, "
        + hasBusinessIds + ">(user_context, module, connection, schema_provider); }");
    line(out, "inline Result<Ref<DataServiceExecutor>, ServiceRuntimeError> serviceRuntime(UserContext& user_context, const ServiceRuntimeConfig& config) {");
    line(out, "auto r = user_context.memory_resource(); using Output = Result<Ref<DataServiceExecutor>, ServiceRuntimeError>;");
    line(out, "if (config.memory_resource() != r) { throw std::invalid_argument(\"Generated runtime configuration requires an explicit destination copy\"); }");
    line(out, "auto connection = open_generated_sqlite_runtime_connection(user_context, config.databaseUrl()); if (!connection) { return Output::err(r, ServiceRuntimeError::from_preparation(r, connection.error())); }");
    line(out, "return Output::ok(r, serviceRuntimeFromConnection(user_context, connection.value())); }");
    line(out, "inline Result<Ref<DataServiceExecutor>, ServiceRuntimeError> serviceRuntimeFromEnv(UserContext& user_context) {");
    line(out, "auto r = user_context.memory_resource(); auto config = ServiceRuntimeConfig::fromEnv(user_context); if (!config) { return Result<Ref<DataServiceExecutor>, ServiceRuntimeError>::err(r, std::move(config).error()); }");
    line(out, "return serviceRuntime(user_context, config.value()); }");
    line(
        out,
        "inline Ref<DataServiceExecutor> configureRuntime(UserContext& user_context, std::string_view filename"
            + " = \":memory:\") {");
    line(
        out,
        "auto& module = moduleWithBehaviorsAndCheckers(user_context);"
            + " module.apply_to(user_context); auto& metadata = module.metadata;");
    line(out, "user_context.set_metadata(user_context, metadata); auto connection = user_context.make_resource_ref<SqliteConnection>(filename); auto& schema_provider = user_context.make<LocalSchemaProvider>();");
    line(out, "return bind_generated_sqlite_runtime<DataServiceExecutor, " + hasBusinessIds
        + ">(user_context, schema_provider, connection); }");
    {
      line(out, "inline Ref<DataServiceExecutor> setup(UserContext& user_context, std::string_view filename = \":memory:\") { auto executor = configureRuntime(user_context, filename); require_value(user_context.ensure_schema().wait()); return executor; }");
    }
    line(out, "}");
    return out.toString();
  }

  private static boolean skipBootstrapField(FieldDescriptor field) {
    return field.isId() || field.isVersion() || field.isCreateTime() || field.isUpdateTime();
  }

  private static String unquoteRustSeed(String literal) {
    if (!literal.startsWith("\"") || !literal.endsWith("\"")) {
      throw new IllegalArgumentException("Unsupported quoted bootstrap literal: " + literal);
    }
    return literal.substring(1, literal.length() - 1).replace("\\\"", "\"").replace("\\\\", "\\");
  }

  private static String bootstrapValue(FieldDescriptor field, Candidate candidate) {
    if (field.isObjectProperty()) { return "std::uint64_t{1}"; }
    String literal = candidate == null ? RustFieldDescriptorNaming.rustRootSeedValue(field)
        : RustFieldDescriptorNaming.rustConstantSeedValue(field, candidate);
    String type = baseType(field);
    String value;
    if (CppBusinessIdMetadata.isBusinessId(field)) {
      value = "GeneratedBusinessIdAccess::from_canonical<" + applicationType(field)
          + ">(r, " + quote(unquoteRustSeed(literal)) + ")";
    } else if (type.equals("String")) {
      value = "String(" + quote(unquoteRustSeed(literal)) + ", r)";
    } else if (type.equals("Date")) {
      value = "Date::from_ymd(1970, 1, 1).value()";
    } else if (type.equals("Timestamp")) {
      value = "Timestamp::now()";
    } else if (type.equals("Decimal")) {
      String raw = candidate == null ? unquoteRustSeed(literal) : field.getCandidateValue(candidate.getLineNumber());
      value = "Decimal::parse(" + quote(raw) + ").value()";
    } else if (type.equals("Json")) {
      if (literal.equals("serde_json::Value::Null")) {
        value = "Json(r)";
      } else {
        String json = literal.substring("serde_json::json!(".length(), literal.length() - 1);
        value = "Json::parse(r, " + quote(json) + ").value()";
      }
    } else {
      value = literal.replace("_u64", "ULL").replace("_i64", "LL")
          .replace("_f32", "f").replace("_f64", "");
    }
    return field.getBooleanAttribute("optional") ? storageType(field) + "{" + value + "}" : value;
  }

  private void bootstrapRecipe(StringBuilder out, ObjectDescriptor entity, boolean root) {
    String name = typeName(entity);
    line(out, "struct " + name + "BootstrapRecipe { using Model = " + name + ";");
    line(out, "static constexpr bool is_root = " + root + ";");
    line(out, "static auto& query(const UserContext& user_context, std::uint64_t id, bool domain_root) {");
    String plural = camel(identifier(PluralizationUtils.pluralize(entity.getName())));
    String idPredicate = camel(identifier(FieldDescriptorNaming.attributePredicatePrefixExpr(entity.findField("id"))) + "_is");
    line(out, "auto& mutable_user_context = const_cast<UserContext&>(user_context); auto Q = mutable_user_context.queries<query_factory>(); return Q."
        + plural + "().selectSelfFields()." + idPredicate + "(id).comment(domain_root ? "
        + quote("what: locate generated Domain Root") + " : " + quote("what: locate generated constant")
        + ").purpose(\"why: idempotent runtime bootstrap\").executeForList(mutable_user_context); }");
    line(out, "static void set_id(Model& entity, std::uint64_t id) { entity.updateId(id); }");
    line(out, "static void set_raw_field(const UserContext& user_context, Model& entity, std::string_view field, const Value& value) { if (!detail::is_generated_schema_bootstrap(user_context)) { throw std::logic_error(\"generated bootstrap assignment requires schema bootstrap scope\"); } entity.root.set(entity.entity_key(), field, value); auto& pool = detail::ContextArena::from_memory(entity.memory_resource()).loaded_snapshots(); entity.load_state.mark_loaded(field, &pool).value(); }");
    for (FieldDescriptor field : entity.getFields()) {
      if (skipBootstrapField(field) || root && field.isObjectProperty()) { continue; }
      line(out, "static void set_" + fieldName(field) + "(const UserContext& user_context, Model& entity, const "
          + storageType(field) + "& value) { if (!detail::is_generated_schema_bootstrap(user_context)) { throw std::logic_error(\"generated bootstrap assignment requires schema bootstrap scope\"); } entity."
          + camel("update_" + fieldName(field)) + "(value); }");
    }
    line(out, "};");
  }

  private void bootstrap(StringBuilder out, List<ObjectDescriptor> entities) {
    List<ObjectDescriptor> roots = entities.stream().filter(entity -> entity.isRoot() && !entity.isConstant()).toList();
    if (roots.size() != 1) {
      throw new IllegalArgumentException("Generated bootstrap requires exactly one Domain Root");
    }
    List<String> steps = new ArrayList<>();
    line(out, "namespace generated_detail {");
    bootstrapRecipe(out, roots.get(0), true);
    for (ObjectDescriptor entity : entities) {
      if (entity.isConstant() && entity != roots.get(0)) { bootstrapRecipe(out, entity, false); }
    }
    List<ObjectDescriptor> sequence = new ArrayList<>();
    sequence.add(roots.get(0));
    sequence.addAll(entities.stream().filter(ObjectDescriptor::isConstant).toList());
    for (int index = 0; index < sequence.size(); ++index) {
      ObjectDescriptor entity = sequence.get(index);
      boolean root_entity = entity == roots.get(0);
      List<Candidate> values = index == 0 ? java.util.Collections.singletonList(null) : entity.getIdentityConstants();
      if (values == null) { continue; }
      for (Candidate candidate : values) {
        boolean root = index == 0;
        long id = root ? 1 : candidate.getId();
        String name = typeName(entity), recipe = name + (root_entity && !root ? "ConstantBootstrap" : "Bootstrap") + id;
        steps.add("run_generated_bootstrap_model<" + recipe + ">");
        line(out, "struct " + recipe + " : " + name + "BootstrapRecipe { static constexpr std::uint64_t fixed_id = " + id + "ULL;");
        line(out, "static constexpr bool is_root = " + root + ";");
        line(out, "static constexpr std::string_view create_reason = " + quote(root ? "create generated Domain Root " + name : "create model constant " + name + "(" + id + ")") + ";");
        line(out, "static constexpr std::string_view reconcile_reason = " + quote("reconcile model constant " + name + "(" + id + ")") + ";");
        line(out, "static auto& query(const UserContext& user_context) { return " + name + "BootstrapRecipe::query(user_context, fixed_id, is_root); }");
        line(out, "static void set_id(Model& entity) { " + name + "BootstrapRecipe::set_id(entity, fixed_id); }");
        line(out, "static bool configure(const UserContext& user_context, Model& entity, bool existing) { auto r = user_context.memory_resource(); bool changed = false;");
        for (FieldDescriptor field : entity.getFields()) {
          if (skipBootstrapField(field) || root && field.isObjectProperty()) { continue; }
          String expected = "expected_" + fieldName(field);
          String rootLiteral = root ? RustFieldDescriptorNaming.rustRootSeedValue(field) : "";
          if (root && rootLiteral.startsWith("\"") && Set.of("Decimal", "float", "double").contains(baseType(field))) {
            line(out, "Value " + expected + "(r, " + quote(unquoteRustSeed(rootLiteral)) + "); "
                + name + "BootstrapRecipe::set_raw_field(user_context, entity, " + quote(canonical(field)) + ", " + expected + "); changed = true;");
            continue;
          }
          line(out, "auto " + expected + " = " + bootstrapValue(field, candidate) + ";");
          // The befriended base recipe owns private assignment access.
          line(out, "if (!existing || entity." + camel(fieldName(field)) + "() != " + expected + ") { "
              + name + "BootstrapRecipe::set_" + fieldName(field) + "(user_context, entity, " + expected + "); changed = true; }");
        }
        line(out, "return changed; } };");
      }
    }
    line(out, "inline GeneratedSchemaBootstrapFuture& ensure_bootstrap(const UserContext& user_context) { const std::array<GeneratedSchemaBootstrap, "
        + steps.size() + "> recipes{" + String.join(", ", steps) + "}; return run_generated_schema_bootstrap(user_context, recipes); }");
    line(out, "}");
  }

  private String camelAssist(String text, String namespace) {
    java.util.regex.Matcher code = java.util.regex.Pattern.compile("`([^`]*)`").matcher(text);
    StringBuffer result = new StringBuffer();
    Set<String> protocols =
        Set.of(
            namespace,
            "user_context",
            "query_factory",
            "audit_as",
            "memory_resource",
            "get_entity",
            "canonical_name",
            "into_query",
            "DATABASE_URL_ENV",
            "target_state",
            "insert_resource",
            "static_cast",
            "const_cast",
            "reinterpret_cast",
            "dynamic_cast",
            "ensure_schema",
            "apply_to",
            "decode_json_entity",
            "decode_json_entities",
            "into_json",
            "chunk_size");
    while (code.find()) {
      // A quoted result key is model data, not an application identifier.
      if (code.group(1).startsWith("\"") && code.group(1).endsWith("\"")) {
        code.appendReplacement(result, java.util.regex.Matcher.quoteReplacement(code.group()));
        continue;
      }
      java.util.regex.Matcher words =
          java.util.regex.Pattern.compile("[A-Za-z_][A-Za-z_0-9]*").matcher(code.group(1));
      StringBuffer snippet = new StringBuffer();
      while (words.find()) {
        String word = words.group();
        boolean standard = code.group(1).substring(0, words.start()).endsWith("std::");
        words.appendReplacement(snippet, protocols.contains(word) || standard ? word : camel(word));
      }
      words.appendTail(snippet);
      code.appendReplacement(result, java.util.regex.Matcher.quoteReplacement("`" + snippet + "`"));
    }
    code.appendTail(result);
    return result.toString();
  }

  private void relationIdentityAssist(StringBuilder out, String entity, String member, String identity) {
    if (member.equals(identity)) {
      return;
    }
    line(out, "Relationship identity for " + entity + ": `" + quote(identity)
        + "` is the metadata, JSON and diagnostic path. The escaped model accessor `"
        + camel(member) + "()` is a C++ identifier only. Q `" + camel("select_" + identity)
        + "()` / `" + camel("select_" + identity + "_with") + "(child)` and E `"
        + camel("get_" + identity) + "()` delegate to the corresponding escaped Q/E methods."
        + " They preserve Context binding and do not issue implicit queries.");
  }

  private String assist(String ns, List<ObjectDescriptor> entities) {
    StringBuilder out =
        new StringBuilder(
            "# Generated C++ model-aware API\n\nNamespace: `"
                + ns
                + "`. Create `auto Q = user_context.queries<query_factory>();`. Allocate with"
                + " UserContext. Execute only after purpose and comment.\n\n");
    line(out, "Standalone registries: `repositoryRegistry(user_context)`, `behaviorRegistry(user_context)` and `checkerRegistry(user_context)` each allocate an independent Context-owned registry using every generated model's canonical name. They do not install themselves into the Context or execute SQL. Runtime registry lookup/replacement APIs retain snake_case; generated defaults are managed objects and checked callback borrows expire with their owner. Same-domain clones share those checked callbacks; cross-domain retention requires separately allocated destination callbacks, not an implicit shared owner.");
    line(out, "`user_context.make<LocalSchemaProvider>()` provides the separate data-service schema lookup SPI. `get_entity(canonical_name)` returns a fresh Context-owned descriptor or null for an unknown/case-mismatched name. It always uses the generated static model descriptor, independently of mutable Context metadata and the runtime schema-initialization provider. Ordinary configuration binds the SQL executor to this provider. DataServiceDialect, DataServiceMutationExecutor, DataServiceMutationError and DataServiceIdGenerator expose the corresponding SQLite provider types; DataServiceConnection remains a checked Context-bound connection reference.");
    line(out, "Runtime configuration: `ServiceRuntimeConfig::fromEnv(user_context)` reads the model-derived `DATABASE_URL_ENV` without caching it. `databaseUrl()` exposes the retained URL. Configuration and typed error payloads use the supplied Context; destroy value wrappers before Context close or explicitly copy into the destination scope.");
    line(out, "`serviceRuntimeFromEnv(user_context)` and `serviceRuntime(user_context, config)` prepare a SQLite URL and return a Result containing a checked executor reference. `serviceRuntimeFromConnection(user_context, connection)` assembles from a checked `DataServiceConnection` (`Ref<SqliteConnection>`), including an explicitly rebound Global connection. Expired and foreign Context references are rejected; configuration from another domain requires an explicit copy. These entries register metadata, Checker/Behavior, IDs, provider and executor but leave schema initialization explicit. `configureRuntime(user_context, filename)` retains its direct filename contract; `setup` additionally ensures schema. Business-ID key providers remain application-installed through UserContext. Typed ServiceRuntimeError preserves MissingEnv, ConnectionError, Configuration, provider and runtime payloads; ordinary C++ binding/allocation exceptions retain their established behavior. URL preparation preserves source slash-pair stripping and query removal; it does not enforce SQLite URI open modes.");
    if (entities.stream().flatMap(entity -> fields(entity).stream()).anyMatch(CppBusinessIdMetadata::isBusinessId)) {
      line(out, "DataServiceBusinessIdAllocator names the SQLite-backed allocation/schema implementation for this modeled Business-ID domain; ordinary domains omit the alias. Register runtime infrastructure before installing the application-owned key provider. Sample generation leaves Business-ID values to configured Checker/Fix; a missing key can fail a governed sample save while earlier commits remain.");
    }
    if (entities.stream().anyMatch(od -> od.getParentOd() != null)) {
      line(out, "Inheritance is supported in normal generation: ancestor fields retain their declaring metadata, each model retains its own table/identity, and typed Q/E, child enhancement and audited graph save use the shared runtime. Type filters/grouping preserve source SQL and may fail when SQLite has no discriminator column. Streams support scalar models; relation/aggregate enhancement is not supported. Inherited Business IDs share the ancestor's value type.\n");
    }
    if (entities.stream().anyMatch(ObjectDescriptor::isConstant)) {
      line(out, "Constant bootstrap uses normal generation. `user_context.ensure_schema()` creates/reconciles the ordinary Domain Root and constants through the shared runtime, governed saves and configured Checker/Policy. Constants retain declaration order and object seeds use identity 1; late targets can fail foreign-key checks. Fixed zero identities retain source allocation behavior and are not idempotent. Bootstrap retries source-defined conflicts up to five attempts; configured audit delivery errors may follow a committed write. Negative identities, candidate naming collisions, invalid roots and unsupported configured scalar carriers reject before output. C++ boolean/JSON and optional Timestamp/reference bindings have independent compiler controls where the original generated Rust crate cannot compile; they are not paired runtime evidence for those broken artifacts.\n");
    }
    for (ObjectDescriptor od : entities) {
      line(out, "## " + typeName(od));
      line(
          out,
          "Entries: `Q."
              + identifier(PluralizationUtils.pluralize(od.getName()))
              + "()` and `Q."
              + identifier(PluralizationUtils.pluralize(od.getName()))
              + "_minimal()`. Evaluation: `E::"
              + identifier(od.getName())
              + "(entity)`.\n");
      line(out, "Matching and scalar relation statistics: with...Matching/without...Matching, rollUpTo...With and field-statistic ...As methods accept unpurposed generated requests, QuerySelection or SelectQuery values. Matching embeds the bare query but retains complete filter metadata; its descriptor always comes from the declared relationship target. Roll-up combines matching and object grouping. Field statistics materialize the selection before adding the aggregate, preserving the original fresh-selection options boundary. SQLite errors for unsupported statistical functions remain errors. All inputs retain checked Context and explicit destination-copy requirements.");
      line(out, "Relation analysis inputs: facetBy...As/AsWithOptions, groupBy...With/WithDetailsFrom, count...With, statsFrom.../As and reverse groupBy...WithDetails accept unpurposed generated requests, QuerySelection and SelectQuery values. Capture preserves complete selection metadata and snapshots without executing a child executor. Requests must share the checked Context binding; all inputs require the destination allocation domain or an explicit destination copy, including User-to-Global capture. Facet children need a nonblank comment at execution. Matching, roll-up and field-statistic methods retain separate conversion contracts.");
      line(out, "Relation selection: `select...With(child)` accepts unpurposed requests from the same or another generated domain, or explicit QuerySelection/SelectQuery values. The runtime captures the materialized selection, including its options, without invoking a child executor. Requests must share the checked Context binding; foreign values require an explicit destination copy. Value inputs are kernel borrows and must remain alive through capture. Target-specific request overloads delegate to the same runtime capture and lifetime checks.");
      line(out, "Child enhancement: `enhanceChild(child)` accepts an unpurposed request from the same or another generated domain, or explicit QuerySelection/SelectQuery values. It snapshots the complete selection and options without executing a child executor. Requests must share the checked Context binding; foreign values require an explicit destination copy. Ordinary wrapper captures preserve binding checks; explicit core values follow the kernel borrow contract.");
      line(out, "Inheritance/query metadata: `matchTypes(types)` accepts Value spans and constrained input ranges, snapshots values into the bound Context and consumes single-pass ranges once. `withTypeGroup()`, `enhanceChild(request)`, `enhanceChildrenIfNeeded()` and `Q."
          + camel(identifier(PluralizationUtils.pluralize(od.getName())))
          + "WithChildren()`. The with-children entry clears slicing, includes self fields and descendants, and does not apply the default live-version filter.\n");
      line(out, "Entity helpers: `" + typeName(od) + "::withId(user_context, id)` constructs a U64 Value in the explicit UserContext domain. `isLoaded(field)` reads scalar/relation availability; `setLoadState(state)` copies into the model's allocation domain and validates its indexed layout before replacement. An incompatible layout throws and preserves the old state; changing availability does not change field values or stage mutations.\n");
      line(out, "General query: `withDeletedRows()`, `deletedRowsOnly()`, `appendSearchCriteria(expr)` and `filterProperty(left, FieldOperator, right)` preserve the source filter rules. `pageOffset(offset, size)`, `pageNumber(number, size)`, `pageDefault(number)`, `offsetOnly(offset)` and `top(size)` are available before/after purpose. Field `unselect...` methods preserve independent aliases; raw SQL methods follow the source explicit trusted-segment API and require application-controlled SQL.\n");
      line(out, "Generic scalar criteria: the field's predicate prefix accepts `(FieldOperator, inputs)` where inputs is a range of values convertible to core Value. `create...Criteria(op, inputs)` is a const method on a bound request and returns `Ref<Expr>` in its allocation scope; append it with `appendSearchCriteria(criteria)` without another Context argument. Foreign UserContext IDs are rejected; use an explicit destination copy. Before/After and BetweenRange helpers retain source comparison and inclusive range semantics. These helpers are not generated for version, Boolean, object-reference or Business-ID fields where the original template omits them.\n");
      line(out, "Scalar membership: source-supported `...In(inputs)` and `...NotIn(inputs)` accept input ranges whose elements convert to core Value, including arrays, vectors, spans and single-pass ranges. Values are copied into the bound request's allocator. Existing typed span overloads remain. The generic range overloads are omitted for Boolean, version, object-reference and Business-ID fields; Business-ID methods keep their distinct typed values. Neither route adds another Context argument.");
      line(out, "Scalar comparisons: ordinary scalar Is/IsNot and non-ID ordered/Between methods also accept values constructible as core Value. Between can use independently typed lower/upper operands. Existing field-typed overloads remain, and the new overloads copy payloads into the bound allocator. Boolean/version/object-reference/Business-ID fields retain their separate contracts; unsupported values fail in constraints.");
      line(out, "Text predicates: source-selected sound-like methods accept Value-constructible operands as well as text. Contains/start/end variants keep their text-only inputs. Generic sound-like overloads are omitted for large-text/password/Business-ID fields. Optional values are not implicitly converted to Value; use an explicit supported Value NULL or TypedNull when the intended criterion needs NULL. Numeric select...WithFunction helpers construct aggregate projections, and unselect removes the plain/raw field projection while preserving independent aliases and aggregates. SQLite rejects unsupported aggregate functions. The current default GBK compiler emits its argument unchanged, so the GBK marker does not establish GBK collation.");
      line(out, "Request state before purpose: `coreQuery()` returns an independent bare core snapshot corresponding to the original query(&self). The existing `query()` keeps the integrated C++ runtime representation. Destroy the snapshot before its allocator closes or explicitly copy it into a destination scope. `relationSelections()`, `relationFilters()` and `childEnhancements()` return read-only Context borrows. `queryOptions()` returns an independent allocator-aware snapshot; destroy it before its owning Context closes or copy it explicitly into a destination scope. `std::move(request).intoQuery()` consumes the request and returns only its core SelectQuery, omitting option metadata and child enhancements as in the original direct into_query method. `std::move(request.selection()).into_query()` is a separate core conversion that applies options and enhancements. Neither conversion grants execution authority or extends Context lifetime. A consumed request rejects later access.");
      line(out, "Relationship analysis: forward `groupBy...With(child)`, `groupBy...WithDetails()`, `groupBy...WithDetailsFrom(child)` and `rollUpTo...With(child)` use matching object queries. Forward/reverse `have...`, `haveNo...`, `with...Matching(child)` and `without...Matching(child)` preserve source membership semantics. Reverse collection `count...`, `count...As(alias)`, `count...With(alias, child)`, `statsFrom...As(alias, child)` and centrally named field aggregates attach results during executeForList/One/Page; executeForRows retains the source raw compact-row behavior.\n");
      for (FieldDescriptor field : fields(od).stream().filter(FieldDescriptor::isObjectProperty).toList()) {
        String relation = RustFieldDescriptorNaming.rustMemberName(field);
        line(out, "Facet: `" + camel("facet_by_" + relation + "_as") + "(name, child)` defaults to all facets; `"
            + camel("facet_by_" + relation + "_as_with_options") + "(name, child, includeAll)` controls outer-query restriction. Matching child relation aggregates receive the outer predicate. Facets attach to list/page results; one executes them before returning the first entity. Rows/count/exists/stream do not execute them. Child facet metadata does not imply recursive generated facet execution.");
      }
      line(out, "Aggregation: `groupBy(field)`, `count()`, `countAs(alias)`, `aggregateCountField(field, alias)`, `aggregateWithFunction(field, alias, function)` and `aggregateSum/Avg/Min/Max/Stddev/StddevPop/VarSamp/VarPop/BitAnd/BitOr/BitXor(field, alias)` build source-shaped aggregate queries. `enableAggregationCache()`, `enableAggregationCacheFor(duration)` and `propagateAggregationCache(duration)` retain cache metadata. Read compact aggregate rows with `executeForRows(user_context)`; SQLite may reject statistical and bitwise functions, matching the source backend.\n");
      line(out, "Execution: `executeForCount(user_context)` returns an unsliced count; `executeForExists(user_context)` retains the query offset and limits to one compact row; `executeForFirst(user_context)` has the same first-or-empty contract as `executeForOne`. `executeForPage(user_context, offset, limit)` returns a typed list with total count. These methods require purpose and nonblank comment; only UserContext supplies runtime dependencies.\n");
      line(out, "Typed JSON presentation: after `module(user_context).apply_to(user_context)`, decode with `user_context.decode_json_entity<"
          + typeName(od) + ">(value)` or `user_context.decode_json_entities<" + typeName(od)
          + ">(array)`. Both return Result and delegate to the shared installed-metadata runtime. Read back with `std::move(entity).into_json(user_context.memory_resource())`; nested loaded views preserve omitted fields, NULL and empty lists. Input cannot authorize a save or replace authoritative database loading. Persistent # fields and incoming runtime state are rejected.\n");
      line(out, "Dynamic JSON: `filterWithJson(text)` applies model-aware self/foreign-key filters, dotted forward/reverse relation membership, `_orderBy`, `_start`, `_size`, `_pageSize` and `_page`. Unknown fields are ignored as in the frozen Rust generator; malformed JSON throws a Context-borrowed diagnostic. Strings become contains predicates; numeric arrays of length two become ranges. Child queries keep their live-row filter even when the leaf is unknown.\n");
      line(out, "Result adaptation: `returnType<Model>()` changes decoding and keeps the source query identity, projections and Context. `newEntity(user_context)` still creates "
          + typeName(od) + ". Result fields require appropriate projections/enhancements; adaptation does not load fields or issue SQL.\n");
      for (ObjectDescriptor child : od.getChildrenOds()) {
        line(out, "- Type filter: `is" + typeName(child) + "()` matches that type and its descendants.");
      }
      for (FieldDescriptor fd : fields(od)) {
        String member = fieldName(fd),
            prefix = identifier(FieldDescriptorNaming.attributePredicatePrefixExpr(fd));
        line(
            out,
            "- Model: `"
                + member
                + (fd.isContextRoot() || fd.isConstantObjectField()
                    ? (fd.isContextRoot()
                        ? "()`; Context-root assignment is managed through UserContext; changed `"
                        : "()`; constant ID assignment is internal; changed `")
                    : "()` / `update_" + member + "(" + argumentType(fd) + ")`; changed `")
                + camel("changed_" + member)
                + "()`; evaluation `"
                + camel("eval_" + member)
                + "()`; expression `get_"
                + member
                + "()`.");
        for (Candidate candidate : candidates(fd)) {
          String suffix = candidate.getRustCandidateMethodValue();
          line(out, "- Candidate filters: `" + camel(prefix + "_is_" + suffix) + "()` and `"
              + camel(prefix + "_is_not_" + suffix) + "()`; exact value `"
              + (fd.isObjectProperty() ? candidate.getId() : candidate.getRustCandidateFilterValue())
              + "`.");
          if (fd.isConstantObjectField()) {
            line(out, "- Candidate model update: `" + camel("update_" + relationName(fd) + "_to_" + suffix)
                + "()`; model and E check: `" + camel(relationName(fd) + "_is_" + suffix)
                + "()`. E preserves NotLoaded and never performs SQL.");
          }
        }
        line(
            out,
            "- Scalar predicates: `"
                + prefix
                + "_is`, `"
                + prefix
                + "_is_not`, `"
                + prefix
                + "_greater_than`, `"
                + prefix
                + "_greater_than_or_equal_to`, `"
                + prefix
                + "_less_than`, `"
                + prefix
                + "_less_than_or_equal_to`. Arguments: `"
                + predicateType(fd)
                + "`.");
        line(
            out,
            "- Range/set/null predicates: `"
                + prefix
                + "_between(lower, upper)`, `"
                + prefix
                + "_in(std::span<const "
                + baseType(fd)
                + ">)`, `"
                + prefix
                + "_not_in(std::span<const "
                + baseType(fd)
                + ">)`, `"
                + prefix
                + "_is_null()`, `"
                + prefix
                + "_is_not_null()`.");
        line(
            out,
            "- Projection/order/group: `select_"
                + member
                + "()`, `order_by_"
                + member
                + "_asc()`, `order_by_"
                + member
                + "_desc()`, `group_by_"
                + (fd.isObjectProperty() ? relationName(fd) : member)
                + "()`.");
        String aggregateMember = fd.isObjectProperty() ? relationName(fd) : member;
        line(out, "- Group/count: `" + camel("group_by_" + aggregateMember) + "()`, `"
            + camel("group_by_" + aggregateMember + "_as") + "(alias)`, `"
            + camel("group_by_" + aggregateMember + "_with_function") + "(alias, function)`, `"
            + camel("count_" + aggregateMember) + "()` and `"
            + camel("count_" + aggregateMember + "_as") + "(alias)`.");
        if (!fd.isObjectProperty()) {
          for (String method : List.of("sum", "avg", "min", "max")) {
            line(out, "- Scalar aggregate: `" + camel(method + "_" + member) + "()` uses alias `"
                + quote(method + "_" + RustFieldDescriptorNaming.rustStorageMemberName(fd)) + "`; `" + camel(method + "_" + member + "_as")
                + "(alias)` sets an explicit result alias. Use executeForRows for aggregate outputs.");
          }
          if (sourceNumericField(fd)) {
            for (String method : List.of("standard_deviation", "square_root_of_population_standard_deviation", "sample_variance", "sample_population_variance")) {
              line(out, "- Statistical aggregate: `" + camel(method + "_" + member) + "()` and `"
                  + camel(method + "_" + member + "_as") + "(alias)`; SQLite requires the corresponding SQL function.");
            }
          }
        }
        if (fd.isBoolean()) {
          line(
              out,
              "- Boolean predicates: `"
                  + identifier(FieldDescriptorNaming.snakeBooleanPredicateExpr(fd))
                  + "()`, `"
                  + identifier(FieldDescriptorNaming.snakeBooleanNegativePredicateExpr(fd))
                  + "()`.");
        }
        if (baseType(fd).equals("String")) {
          line(
              out,
              "- Text predicates: `"
                  + identifier(FieldDescriptorNaming.stringContainsPredicateExpr(fd))
                  + "(text)`, `"
                  + identifier(FieldDescriptorNaming.StringStartsWithPredicateExpr(fd))
                  + "(text)`, `"
                  + identifier(FieldDescriptorNaming.StringEndsWithPredicateExpr(fd))
                  + "(text)`.");
        }
        if (fd.isObjectProperty()) {
          String target = typeName(((ObjectType) fd.getFieldType()).getRefer()),
              relation = relationName(fd);
          line(
              out,
              "- Forward relation: `"
                  + relation
                  + "()` returns const "
                  + target
                  + (fd.isContextRoot() || fd.isConstantObjectField()
                      ? (fd.isContextRoot()
                          ? "*; Context-root assignment is managed through UserContext; query `select_"
                          : "*; constant assignment uses candidate update methods; query `select_")
                      : "*, `update_" + relation + "(const " + target + "&)`; query `select_")
                  + relation
                  + "()`, `select_"
                  + relation
                  + "_with("
                  + target
                  + "Request<P>)`, `"
                  + prefix
                  + "("
                  + target
                  + "Request<P>)`; expression `get_"
                  + relation
                  + "()`.");
        }
      }
      for (FieldDescriptor field : fields(od)) {
        if (field.isObjectProperty()) {
          line(
              out,
              "- Model relation evaluation: `"
                  + camel("eval_" + relationName(field))
                  + "()` returns a checked entity borrow or Null/NotLoaded.");
        }
      }
      for (ReverseRelation rel : od.getReverseRelations()) {
        String member = relationName(rel), target = typeName(rel.getChild());
        line(
            out,
            "- Model relation evaluation: `"
                + camel("eval_" + member)
                + "()`; query view handle: `"
                + camel(member + "_handle")
                + "()`.");
        line(
            out,
            "- Reverse relation: `"
                + member
                + "()` returns "
                + (ReverseRelationNaming.oneToOne(rel)
                    ? "const " + target + "*"
                    : "SmartList<" + target + ">&")
                + "; query `select_"
                + member
                + "()`, `select_"
                + member
                + "_with("
                + target
                + "Request<P>)`, `with_"
                + member
                + "("
                + target
                + "Request<P>)`; expression `get_"
                + member
                + "()`.");
      }
    }
    line(
        out,
        "\n"
            + "Common request methods: `comment(text)`, `purpose(text)`, `filter(expr)`,"
            + " `andFilter(expr)`, `orFilter(expr)`, `selectSelf()`, `selectSelfFields()`,"
            + " `limit(n)`, `offset(n)`, `skip(n)`, `hardLimit(n)`, `searchWithText(text)`."
            + " Purpose stages an executable type; modifiers remain available.");
    line(out, "Embedded child requests must remain unpurposed: select relations, enhance children,"
        + " facets, relation matching, grouping and aggregates with a child before its purpose()"
        + " transition. The parent retains its own purpose; ordinary C++ modifiers may appear"
        + " before or after that parent transition. Keep child comments and filters on the child."
        + " Root execution still requires both a nonblank comment and purpose.");
    line(out, "Membership: matchingAnyOf(child) and matchAnyOf(child) compare root IDs with"
        + " the child's ID subquery. They copy its core query, including selected relations,"
        + " but do not import its independent selection options, comment, raw SQL or enhancements."
        + " Ordinary child requests may come from another generated executor domain."
        + " Keep the child unpurposed and in the same UserContext, or copy it explicitly first."
        + " Direct QuerySelection and SelectQuery inputs are also accepted in the receiving allocation scope."
        + " selection() captures independent options; moving that value into into_query() applies them"
        + " before core-query membership. Use Context make() for retained conversion payloads;"
        + " stack-owned payloads must be destroyed before their Context closes.");
    line(
        out,
        "Dynamic fields: Q requests provide `selectDynamicFields(selection)`; models provide"
            + " `dynamicFieldValues()`, `updateDynamicField(code, value)`,"
            + " `deleteDynamicField(code)` and `hasPendingDynamicMutations()`."
            + " Durable fields use the runtime Context provider and audited ledger save;"
            + " native getters and mutation values remain separate.");
    line(out,
        "Readonly computed properties: `hasDynamicProperty(key)` reports an underscore-key"
            + " projection even when its value is NULL; `dynamicProperty(key)` returns a borrowed"
            + " non-NULL value, treating typed NULL and JSON null as absent."
            + " False, zero and empty text remain readable. These accessors do not allocate,"
            + " execute SQL or grant durable dynamic-field write authority; returned values"
            + " borrow the model's Context.");
    line(out,
        "Context operations: `stream(chunk_size)`, `copyTo(user_context)`,"
            + " `copyToGlobal(user_context)`, `rebindGlobal(user_context)`. Mutable request copies"
            + " are independent; retained copies are explicit.");
    line(
        out,
        "Executable methods (exactly one UserContext argument): `execute_for_list(user_context)`,"
            + " `execute_for_entity_list(user_context)`, `execute(user_context)`,"
            + " `execute_for_one(user_context)`, `execute_for_stream(user_context)`,"
            + " `execute_for_entity(user_context)`, `execute_for_rows(user_context)`,"
            + " `new_entity(user_context)`. Pollable results use `.wait()`; only newEntity returns"
            + " a managed model directly.");
    line(
        out,
        "Expression methods: `eval()`, `unwrap()`, `is_null()`, `is_not_null()`,"
            + " `or_if_null(fallback)`, `or_else_if_null(callback)`, `or_default_if_null()`. List"
            + " expressions add `size()` (scalar expression), `first()` and `get(index)` (entity"
            + " expressions). NotLoaded is never a NULL fallback.");
    line(out, "Default NULL fallback is available only for scalar payloads with a default"
        + " value. Strong Business ID payloads have no public default: use a typed"
        + " `orIfNull(fallback)` or `orElseIfNull(callback)` instead."
        + " Missing-load errors never invoke a fallback.");
    line(out, "Missing-load diagnostics: catch `ExpressionNotLoadedError` and inspect"
        + " `error.diagnostic()` for the captured root, access_path, failed_node, missing_preload,"
        + " suggested_fix, optional nested_fix, severity and English human_message."
        + " Suggestions use generated C++ camelCase selection names. The error borrows its"
        + " Context; diagnostic access fails after close. `what()` is static and remains safe."
        + " Retention requires an explicit destination copy before closing the source Context.");
    line(out, "Diagnostic repair scope: a loaded relationship can leave a leaf-only diagnostic"
        + " path. Apply the selection to that relationship's child request and retain the"
        + " enclosing selection. Nested C++ selections use `select...With(child)`; leaf"
        + " selections use `select...()`. Renderer entry placeholders and captured id=..."
        + " expressions are explanatory pseudocode. Use current object/field Assist to resolve"
        + " the actual Q entry, child type and selection names before executing a repair.");
    line(
        out,
        "Expression composition: `map(callback)`, `andThen(node, callback)` and owning scalar"
            + " `copyTo(user_context)`. Entity/list bindings are checked borrows; temporary entity"
            + " entries are rejected. Scalar access is an eager snapshot. All Q/E wrappers expire"
            + " with their scope; Global diagnostics must outlive surviving wrappers.");
    line(
        out,
        "Save: `AuditedSaveExt<Model>::save(std::move(entity).audit_as(\"reason\"),"
            + " user_context).wait()`. Allocate requests/models with UserContext and call"
            + " setup(user_context) once at bootstrap. Use explicit destination copies before"
            + " closing the owning context. Unknown fields are compile errors.");
    line(out, "Sample data: `generateSampleData(user_context, SampleDataPlan{SampleDataScale::Tiny, seed}).wait()` uses Context-bound queries and audited saves. It loads roots/constants, skips missing required dependencies, and generates business rows in depth/name order. Run setup first. Reference selection and numeric values follow the seed/index rules; temporal fields use the wall clock. Repeated calls create additional business rows. Reports and errors belong to UserContext; copy explicitly before close.");
    line(out, "Sample failure: generation stops at the first save error; earlier successful saves remain committed. A failed invocation returns an error, and a later invocation may create another business batch.");
    if (entities.stream().anyMatch(entity -> entity.getDepth() > 0 && !entity.isConstant()
        && fields(entity).stream().anyMatch(field -> baseType(field).equals("String")
            && !field.isString() && !field.isJsonLiteral()
            && (field.isNumber() || field.getBooleanAttribute("isNumber"))))) {
      line(out, "Numeric sample recipes for String-mapped aliases retain the original integer operand. Generated typed Checkers can reject entity materialization before custom CheckerLogic runs. The runtime does not silently convert the operand to text; modules without those checkers retain the provider's actual behavior. Use explicitly typed application values when this model's sample save fails.");
    }
    line(out, "Sample progress: register an application-owned `SampleDataLogSink` through `user_context.insert_resource(owner, static_cast<SampleDataLogSink&>(sink))`. Its synchronous `info(user_context, message)` receives the original sample Info messages in execution order. Allocate the sink in the declared Global/User owner; `memory_resource()` must identify that owner. Missing or disabled sinks do not format messages. Messages are callback borrows; retaining them requires an explicit copy into the sink owner's allocator. Pending re-polls do not repeat start; cancellation and save failure emit no successful completion. A callback must not close its active Context, and exceptions propagate as operation failure. This sample-specific sink does not replace SQL diagnostics or audit sinks.");
    if (entities.stream().anyMatch(entity -> entity.getDepth() > 0 && !entity.isConstant()
        && CppFieldLayoutMetadata.fields(entity).stream().anyMatch(field -> baseType(field).equals("Json") && (field.isString() || field.isJsonLiteral())))) {
      line(out, "JSON sample text follows the locked source setter operand and can fail typed checking. The sample generator does not silently turn that text into valid JSON. Initialize JSON models with explicit typed values when sample generation reports an error. Complete quoted JSON-literal source generation also has a retained compiler failure; no complete sample parity is advertised for that configuration.");
    }
    line(out, "Deletion: `entity.markForDeletion()` records deletion in the ledger and returns"
        + " the model for chaining. Save through the audited save API; marking alone does"
        + " not execute SQL. Versioned SQLite models use the runtime soft-delete protocol.");
    line(out, "Projection shortcuts: `selectSelfFields()` and `selectSelfWithoutParent()`"
        + " both select native fields, including inherited fields as the original generator"
        + " does. `selectAll()` also selects forward and reverse to-one relations;"
        + " `selectChildren()` adds reverse collections, and `selectAny()` aliases it."
        + " These do not replace `enhanceChildrenIfNeeded()` for polymorphic descendants."
        + " Named relation selections can include soft-deleted child rows; they do not"
        + " automatically apply a child Q entry's default live-row filter. Use an explicit"
        + " select...With(child_request) to carry the child's filters and projection.");
    line(out, "Runtime attachment: `entity.attachRuntimeStateRecursive(target_state)` adopts"
        + " pending mutations and preserves the entity's loaded snapshot. It recursively"
        + " attaches stored forward objects; it does not load relations or traverse graph"
        + " lookups/reverse collections. Both states must belong to the same Context;"
        + " cross-domain retention requires an explicit destination copy.");
    List<String> sourceIdentityDifferences = entities.stream().flatMap(entity -> descriptorFields(entity).stream())
        .filter(field -> !canonical(field).equals(RustFieldDescriptorNaming.rustStorageMemberName(field)))
        .map(field -> quote(canonical(field)) + " -> " + quote(RustFieldDescriptorNaming.rustStorageMemberName(field)))
        .distinct().toList();
    if (!sourceIdentityDifferences.isEmpty()) {
      line(out, "Source metadata boundary: query projections retain storage names while descriptors retain the original Rust member identities: `"
          + String.join(", ", sourceIdentityDifferences) + "`. Queries of these fields can preserve the original unknown-field SQL failure. The adapter does not silently rename query fields to make that source configuration succeed.");
    }
    line(out, "## Business IDs");
    for (ObjectDescriptor entity : entities) {
      for (FieldDescriptor field : fields(entity)) {
        if (CppBusinessIdMetadata.isBusinessId(field)) {
          String type = applicationType(field);
          line(
              out,
              "- `"
                  + type
                  + "::create(user_context.memory_resource(), text)` trims and rejects blank text;"
                  + " `asStr()` exposes canonical text. Model setter `"
                  + camel("update_" + fieldName(field))
                  + "(const "
                  + type
                  + "&)` and scalar predicates accept this distinct type."
                  + " `definition(user_context.memory_resource())` exposes its configured profile."
                  + " Creation uses the trusted active root, allocation service and fix evidence;"
                  + " dirty Business IDs are immutable on update.");
        }
      }
    }
    if (entities.stream()
        .flatMap(entity -> fields(entity).stream())
        .anyMatch(CppBusinessIdMetadata::isBusinessId)) {
      line(
          out,
          "setup installs SQLite Business-ID infrastructure. Register an explicit"
              + " BusinessIdKeyProvider through UserContext before daily-permuted-v1 creation; no"
              + " default key or hidden owner is introduced. Use with_active_root before allocating"
              + " aggregate IDs.");
    }
    line(out, "## Model relation evaluation");
    line(
        out,
        "Model evalX() and E.getX() share the runtime relation rules. Loaded empty lists are"
            + " values, selected empty to-one relations are Null, and missing views are NotLoaded."
            + " Returned entity/list values are checked Context borrows. Reverse XHandle() methods"
            + " expose the immutable query-installed view; existing mutable list getters remain"
            + " explicit model-local graph construction adapters. No getter performs implicit"
            + " SQL.");
    line(out, "## Checker and behavior assembly");
    line(out, "Wire metadata: `generatedWireFieldMappings(user_context)` returns Context-owned typed maps from canonical model field names to the selected JSON wire spelling. Like the original template, each entity entry lists its own fields; it does not flatten inherited fields or rename relation keys to FK storage keys. `generatedWireFieldAliases(user_context)` returns the separately defined empty legacy-alias map. These functions do not install metadata, authorize client input or provide a transport endpoint. Explicit destination copying is required to retain the maps after Context close.");
    line(
        out,
        "`configureRuntime(user_context, filename)` installs generated metadata, checkers and"
            + " behaviors, the SQLite provider, scoped persistent IDs and the application executor."
            + " It does not create schema. `setup(user_context, filename)` performs that configuration"
            + " and waits for `user_context.ensure_schema().wait()`; its default filename is `:memory:`.");
    line(
        out,
        "Use `module(user_context)` for metadata-only registration, or"
            + " `moduleWithCheckers(user_context)`, `moduleWithBehaviors(user_context)` or"
            + " `moduleWithBehaviorsAndCheckers(user_context)` for explicit assembly. Keep"
            + " handwritten logic outside generated files.");
    line(out, "For custom assembly, call `configureRuntime(user_context, filename)` first, then"
        + " register application-owned Checker/Behavior overrides with a module and apply it"
        + " before `user_context.ensure_schema().wait()` or business execution. Calling"
        + " `configureRuntime` or `setup` again installs defaults and replaces those registrations.");
    if (hasGeneratedBootstrap(entities)) {
      line(out, "All four module factories register schema bootstrap. Schema initialization prepares"
          + " the generated Domain Root and active-root binding; reuse that root instead of inserting"
          + " a second ID 1. Repeated initialization preserves existing root values. Bootstrap"
          + " errors propagate; do not treat a failed `setup` as a usable initialized Context.");
    }
    for (ObjectDescriptor od : entities) {
      String name = typeName(od);
      line(
          out,
          "- Extend `"
              + name
              + "CheckerLogic` and override `checkAndFix"
              + name
              + "(user_context, entity, status, location, results)`. Allocate logic in an explicit"
              + " Context, create `"
              + name
              + "Checker` with that logic and register its `TypedEntityChecker` adapter. The"
              + " built-in Context/time fixes and predefined update-load checks run before custom"
              + " logic.");
      line(
          out,
          "- `"
              + name
              + "Behavior` preserves the EntityDataServiceBehavior SPI; runtime hook names retain"
              + " snake_case.");
    }
    for (ObjectDescriptor od : entities) {
      for (FieldDescriptor field : fields(od)) {
        if (field.isObjectProperty()) {
          relationIdentityAssist(out, typeName(od), relationName(field), relationIdentity(field));
        }
      }
      for (ReverseRelation relation : od.getReverseRelations()) {
        relationIdentityAssist(out, typeName(od), relationName(relation), relationIdentity(relation));
      }
    }
    return camelAssist(out.toString(), ns);
  }

  /** Local, offline entry point; uses exactly the service's model parser/discovery. */
  public static void main(String[] args) throws Exception {
    Set<String> flags = args.length < 2 ? Set.of() : new HashSet<>(Arrays.asList(args).subList(2, args.length));
    if (args.length < 2 || !Set.of("--qualify-inheritance", "--qualify-constants").containsAll(flags)) {
      throw new IllegalArgumentException("Usage: CppCoreGenerator MODEL OUTPUT_DIRECTORY [--qualify-inheritance] [--qualify-constants]");
    }
    Path model = Path.of(args[0]).toAbsolutePath();
    Path output = Path.of(args[1]).toAbsolutePath().normalize();
    GenerateContext context = new GenerateContext(SCOPE, model.getFileName().toString());
    context.setEntranceFile(model.getFileName().toString());
    context.appendFile(model.getFileName().toString(), Files.readAllBytes(model));
    BaseDomainManager manager = new BaseDomainManager();
    Domain domain = manager.getDomain(manager.parse(context));
    List<GeneratedFile> generated = args.length > 2
        ? new CppCoreGenerator(flags.contains("--qualify-inheritance"), flags.contains("--qualify-constants")).generate(domain)
        : new DomainGenerationService().generateDomainFiles(domain, SCOPE);
    for (GeneratedFile file : generated) {
      Path target = output.resolve(file.getPath()).normalize();
      if (!target.startsWith(output)) {
        throw new IllegalArgumentException("Invalid generated path: " + file.getPath());
      }
      Files.createDirectories(target.getParent());
      Files.write(target, file.getData());
    }
  }
}
